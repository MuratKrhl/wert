import { useState } from 'react';
import { usePendingCount } from '../hooks/useAnsible';
import OverviewPanel from '../components/OverviewPanel';
import TemplateList from '../components/TemplateList';
import JobsPanel from '../components/JobsPanel';
import ApprovalsPanel from '../components/ApprovalsPanel';
import LaunchForm from '../components/LaunchForm';
import JobOutputPanel from '../components/JobOutputPanel';

const TABS = [
  { id: 'overview',   label: 'Özet',       icon: '⬡' },
  { id: 'templates',  label: 'Templates',  icon: '◫' },
  { id: 'jobs',       label: 'Jobs',       icon: '▶' },
  { id: 'approvals',  label: 'Approvals',  icon: '✓' },
];

export default function AnsibleSidebar({ open = true, onClose }) {
  const [tab, setTab] = useState('overview');
  const [launchTarget, setLaunchTarget] = useState(null);   // template to launch
  const [outputJob, setOutputJob] = useState(null);          // job to stream
  const pendingCount = usePendingCount();

  if (!open) return null;

  const handleLaunched = (res) => {
    setLaunchTarget(null);
    setOutputJob({ job_id: res.job_id, template_name: res.template_name ?? launchTarget?.name });
    setTab('jobs');
  };

  return (
    <>
      {/* Sidebar panel */}
      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0,
        width: 380, background: '#050d1a',
        borderLeft: '1px solid #1e3a5f',
        display: 'flex', flexDirection: 'column',
        fontFamily: "'IBM Plex Mono', monospace",
        zIndex: 900,
        boxShadow: '-20px 0 60px rgba(0,0,0,0.5)',
      }}>
        {/* ── Header ── */}
        <div style={{
          padding: '16px 20px 12px',
          borderBottom: '1px solid #1e3a5f',
          background: '#0a1628',
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8, background: 'linear-gradient(135deg, #0369a1, #1d4ed8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 14, flexShrink: 0,
          }}>
            ⚙
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0', letterSpacing: 1 }}>ANSIBLE</div>
            <div style={{ fontSize: 10, color: '#64748b', letterSpacing: 1 }}>AUTOMATION CONSOLE</div>
          </div>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', color: '#64748b', fontSize: 18, cursor: 'pointer', padding: 4 }}
          >
            ×
          </button>
        </div>

        {/* ── Tabs ── */}
        <div style={{
          display: 'flex', borderBottom: '1px solid #1e3a5f',
          background: '#0a1628',
        }}>
          {TABS.map((t) => {
            const active = tab === t.id;
            const badge = t.id === 'approvals' && pendingCount > 0;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                style={{
                  flex: 1, padding: '10px 4px', border: 'none', background: 'none',
                  borderBottom: `2px solid ${active ? '#38bdf8' : 'transparent'}`,
                  color: active ? '#38bdf8' : '#64748b',
                  cursor: 'pointer', fontSize: 9, letterSpacing: 1,
                  fontFamily: 'inherit', transition: 'all 0.15s',
                  position: 'relative',
                }}
              >
                <div style={{ fontSize: 14, marginBottom: 2 }}>{t.icon}</div>
                {t.label.toUpperCase()}
                {badge && (
                  <div style={{
                    position: 'absolute', top: 6, right: '50%', transform: 'translateX(8px)',
                    width: 16, height: 16, borderRadius: '50%', background: '#f59e0b',
                    color: '#000', fontSize: 9, fontWeight: 700,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {pendingCount > 9 ? '9+' : pendingCount}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* ── Content ── */}
        <div style={{ flex: 1, overflowY: 'hidden', padding: '16px 16px', display: 'flex', flexDirection: 'column' }}>
          {tab === 'overview' && (
            <OverviewPanel onTabChange={setTab} />
          )}
          {tab === 'templates' && (
            <TemplateList
              onLaunch={setLaunchTarget}
              onViewOutput={setOutputJob}
            />
          )}
          {tab === 'jobs' && (
            <JobsPanel onViewOutput={setOutputJob} />
          )}
          {tab === 'approvals' && (
            <ApprovalsPanel />
          )}
        </div>
      </div>

      {/* Modals */}
      {launchTarget && (
        <LaunchForm
          template={launchTarget}
          onLaunched={handleLaunched}
          onClose={() => setLaunchTarget(null)}
        />
      )}
      {outputJob && (
        <JobOutputPanel
          job={outputJob}
          onClose={() => setOutputJob(null)}
        />
      )}
    </>
  );
}
