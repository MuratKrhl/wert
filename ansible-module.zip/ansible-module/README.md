# Ansible Sidebar — Kullanım

## Klasör Yapısı

```
src/
└── ansible-module/
    ├── AnsibleSidebar.jsx        ← Ana entry point
    ├── api/
    │   └── ansible.js            ← Tüm API çağrıları
    ├── hooks/
    │   └── useAnsible.js         ← Custom React hooks
    └── components/
        ├── OverviewPanel.jsx     ← Özet widget
        ├── TemplateList.jsx      ← Template listesi + arama + favori
        ├── JobsPanel.jsx         ← Job listesi + filtre
        ├── ApprovalsPanel.jsx    ← Approval yönetimi
        ├── LaunchForm.jsx        ← Dinamik launch formu (modal)
        └── JobOutputPanel.jsx    ← Job output polling (modal)
```

---

## Entegrasyon

```jsx
// App.jsx veya Dashboard.jsx
import { useState } from 'react';
import AnsibleSidebar from './ansible-module/AnsibleSidebar';

export default function App() {
  const [ansibleOpen, setAnsibleOpen] = useState(false);

  return (
    <div>
      {/* Mevcut dashboard içeriğin */}
      <main>...</main>

      {/* Ansible toggle butonu — istediğin yere koy */}
      <button onClick={() => setAnsibleOpen(true)}>
        Ansible ⚙
      </button>

      {/* Sidebar */}
      <AnsibleSidebar
        open={ansibleOpen}
        onClose={() => setAnsibleOpen(false)}
      />
    </div>
  );
}
```

---

## Font (opsiyonel)

IBM Plex Mono kullanıldı. `index.html` veya `index.css` içine ekle:

```html
<link
  href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600;700&display=swap"
  rel="stylesheet"
/>
```

---

## API Base URL

`api/ansible.js` içinde `BASE` değişkeni `/api/ansible` olarak ayarlı.
Django dev sunucusu farklı porttaysa `vite.config.js` içine proxy ekle:

```js
// vite.config.js
export default {
  server: {
    proxy: {
      '/api': 'http://localhost:8000'
    }
  }
}
```

---

## Bileşen Özellikleri

| Bileşen | Özellik |
|---|---|
| TemplateList | Arama, tip filtresi, favori toggle, pagination |
| LaunchForm | AWX survey tüm tipleri: text, textarea, password, integer, email, multiplechoice, multiselect |
| JobOutputPanel | Cursor-based polling, syntax highlight (TASK/PLAY/ok/failed), retry_after_ms destekli |
| ApprovalsPanel | Approve / Deny + opsiyonel gerekçe alanı |
| OverviewPanel | 4 istatistik kartı + son çalışmalar, tab navigasyonu |
| AnsibleSidebar | Pending approval badge, launch → output akışı otomatik |
