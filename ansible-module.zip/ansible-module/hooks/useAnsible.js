import { useState, useEffect, useRef, useCallback } from 'react';
import * as api from '../api/ansible';

// ── Generic fetch hook ─────────────────────────────────────────────────────
export function useFetch(fetcher, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetcher();
      setData(result);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  }, deps); // eslint-disable-line

  useEffect(() => { load(); }, [load]);

  return { data, loading, error, reload: load };
}

// ── Templates ──────────────────────────────────────────────────────────────
export function useTemplates(params) {
  return useFetch(() => api.getTemplates(params), [JSON.stringify(params)]);
}

export function useLaunchConfig(templateId) {
  return useFetch(() => api.getLaunchConfig(templateId), [templateId]);
}

// ── Overview ───────────────────────────────────────────────────────────────
export function useOverview() {
  return useFetch(api.getOverview, []);
}

// ── Jobs ───────────────────────────────────────────────────────────────────
export function useJobs(params) {
  return useFetch(() => api.getJobs(params), [JSON.stringify(params)]);
}

export function useJob(jobId) {
  return useFetch(() => api.getJob(jobId), [jobId]);
}

// ── Job Output Polling ─────────────────────────────────────────────────────
export function useJobOutput(jobId, active = true) {
  const [lines, setLines] = useState([]);
  const [status, setStatus] = useState('pending');
  const cursorRef = useRef(0);
  const timerRef = useRef(null);

  const poll = useCallback(async () => {
    if (!jobId) return;
    try {
      const res = await api.getJobOutput(jobId, cursorRef.current);
      if (res.output?.length) {
        setLines((prev) => [...prev, ...res.output]);
        cursorRef.current = res.next_cursor;
      }
      setStatus(res.status);
      if (res.status === 'running' || res.status === 'pending') {
        const delay = res.retry_after_ms ?? 2000;
        timerRef.current = setTimeout(poll, delay);
      }
    } catch (_) {
      timerRef.current = setTimeout(poll, 3000);
    }
  }, [jobId]);

  useEffect(() => {
    if (!active || !jobId) return;
    setLines([]);
    cursorRef.current = 0;
    poll();
    return () => clearTimeout(timerRef.current);
  }, [jobId, active, poll]);

  return { lines, status };
}

// ── Approvals ──────────────────────────────────────────────────────────────
export function useApprovals() {
  return useFetch(api.getApprovals, []);
}

export function usePendingCount() {
  const { data } = useFetch(api.getPendingCount, []);
  return data?.count ?? 0;
}

// ── Favorites ─────────────────────────────────────────────────────────────
export function useFavorites() {
  const [favorites, setFavorites] = useState(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getFavorites()
      .then((res) => setFavorites(new Set(res.items?.map((f) => f.template_id))))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const toggle = useCallback(async (template) => {
    const isFav = favorites.has(template.id);
    setFavorites((prev) => {
      const next = new Set(prev);
      isFav ? next.delete(template.id) : next.add(template.id);
      return next;
    });
    try {
      if (isFav) {
        await api.removeFavorite(template.id);
      } else {
        await api.addFavorite({
          template_id: template.id,
          template_name: template.name,
          template_type: template.type,
        });
      }
    } catch (_) {
      // rollback
      setFavorites((prev) => {
        const next = new Set(prev);
        isFav ? next.add(template.id) : next.delete(template.id);
        return next;
      });
    }
  }, [favorites]);

  return { favorites, toggle, loading };
}
