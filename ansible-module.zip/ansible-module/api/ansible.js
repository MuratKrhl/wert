const BASE = '/api/ansible';

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw data;
  return data;
}

// ── Templates ──────────────────────────────────────────────────────────────
export const getTemplates = (params = {}) => {
  const q = new URLSearchParams(params).toString();
  return request(`/templates${q ? `?${q}` : ''}`);
};

export const getTemplate = (id) => request(`/templates/${id}`);

export const getLaunchConfig = (id) => request(`/templates/${id}/launch-config`);

export const launchTemplate = (id, body) =>
  request(`/templates/${id}/launch`, { method: 'POST', body: JSON.stringify(body) });

// ── Jobs ───────────────────────────────────────────────────────────────────
export const getJobs = (params = {}) => {
  const q = new URLSearchParams(params).toString();
  return request(`/jobs${q ? `?${q}` : ''}`);
};

export const getJob = (jobId) => request(`/jobs/${jobId}`);

export const getJobOutput = (jobId, cursor = 0) =>
  request(`/jobs/${jobId}/output?cursor=${cursor}&format=json`);

// ── Approvals ──────────────────────────────────────────────────────────────
export const getApprovals = () => request('/approvals');
export const getPendingCount = () => request('/approvals/pending-count');
export const approveApproval = (id, reason = '') =>
  request(`/approvals/${id}/approve`, { method: 'POST', body: JSON.stringify({ reason }) });
export const denyApproval = (id, reason = '') =>
  request(`/approvals/${id}/deny`, { method: 'POST', body: JSON.stringify({ reason }) });

// ── Overview ───────────────────────────────────────────────────────────────
export const getOverview = () => request('/overview');

// ── Favorites ─────────────────────────────────────────────────────────────
export const getFavorites = () => request('/favorites');
export const addFavorite = (body) =>
  request('/favorites', { method: 'POST', body: JSON.stringify(body) });
export const removeFavorite = (templateId) =>
  request(`/favorites/${templateId}`, { method: 'DELETE' });
