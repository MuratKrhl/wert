// ─── permissions/PermissionGate.jsx ─────────────────────────────────────────
//
// Sayfa içindeki bileşenleri / butonları koşullu render eder.
// İzin yoksa children render edilmez (veya fallback gösterilir).
//
// ── Kullanım örnekleri ───────────────────────────────────────────────────────
//
// 1) Bileşen görünürlüğü:
//    <PermissionGate group={user.group} component="deleteBtn">
//      <DeleteButton />
//    </PermissionGate>
//
// 2) CRUD işlemi:
//    <PermissionGate group={user.group} resource="products" op="c">
//      <AddProductButton />
//    </PermissionGate>
//
// 3) Veri kapsamı:
//    <PermissionGate group={user.group} dataScope="financialData">
//      <RevenueChart />
//    </PermissionGate>
//
// 4) Fallback ile:
//    <PermissionGate group={user.group} component="exportBtn" fallback={<Tooltip>Yetkiniz yok</Tooltip>}>
//      <ExportButton />
//    </PermissionGate>

import { usePermissions } from './PermissionsContext';

/**
 * @param {object}  props
 * @param {'admin'|'user'} props.group
 * @param {string}  [props.component]  — bileşen görünürlüğü kontrolü
 * @param {string}  [props.resource]   — CRUD kaynak adı
 * @param {'c'|'r'|'u'|'d'} [props.op] — CRUD işlemi (resource ile birlikte)
 * @param {string}  [props.dataScope]  — veri kapsamı kontrolü
 * @param {React.ReactNode} [props.fallback] — izin yoksa gösterilecek (default: null)
 * @param {React.ReactNode} props.children
 */
export function PermissionGate({
  group,
  component,
  resource,
  op,
  dataScope,
  fallback = null,
  children,
}) {
  const { canSeeComponent, canDo, canAccessData } = usePermissions();

  let allowed = true;

  if (component !== undefined) {
    allowed = canSeeComponent(group, component);
  } else if (resource !== undefined && op !== undefined) {
    allowed = canDo(group, resource, op);
  } else if (dataScope !== undefined) {
    allowed = canAccessData(group, dataScope);
  }

  return allowed ? children : fallback;
}
