// ─── Kullanım Örnekleri ───────────────────────────────────────────────────────
// Bu dosyayı silip kendi bileşenlerinizde aşağıdaki kalıpları kullanabilirsiniz.

import { usePermissions }  from './permissions/PermissionsContext';
import { PermissionGate }  from './permissions/PermissionGate';
import { ProtectedRoute }  from './permissions/ProtectedRoute';

// ─── 1) Hook ile manuel kontrol ───────────────────────────────────────────────
function ProductsPage({ currentUser }) {
  const { canDo, canSeeComponent, canAccessData } = usePermissions();
  const g = currentUser.group;

  return (
    <div>
      <h1>Ürünler</h1>

      {/* Sadece create izni olanlar butonu görür */}
      {canDo(g, 'products', 'c') && (
        <button>Yeni Ürün Ekle</button>
      )}

      {/* Fiyat kolonu izni */}
      {canSeeComponent(g, 'priceColumn') && (
        <th>Fiyat</th>
      )}

      {/* Finansal veri izni */}
      {canAccessData(g, 'financialData') && (
        <RevenueWidget />
      )}
    </div>
  );
}

// ─── 2) PermissionGate bileşeni ile deklaratif kullanım ──────────────────────
function OrdersPage({ currentUser }) {
  const g = currentUser.group;

  return (
    <div>
      {/* Bileşen görünürlüğü */}
      <PermissionGate group={g} component="exportBtn">
        <ExportButton />
      </PermissionGate>

      {/* CRUD işlem */}
      <PermissionGate group={g} resource="orders" op="d">
        <DeleteOrderButton />
      </PermissionGate>

      {/* Fallback ile — izin yoksa tooltip göster */}
      <PermissionGate
        group={g}
        component="bulkActions"
        fallback={<span title="Bu işlem için yetkiniz yok">Toplu İşlem ⓘ</span>}
      >
        <BulkActionsMenu />
      </PermissionGate>

      {/* Veri kapsamı */}
      <PermissionGate group={g} dataScope="allUsers">
        <AllUsersTable />
      </PermissionGate>
    </div>
  );
}

// ─── 3) Route koruması ────────────────────────────────────────────────────────
//
// App.jsx içinde:
//
//   <Route
//     path="/finance"
//     element={
//       <ProtectedRoute page="finance" group={currentUser.group} fallback="/dashboard">
//         <FinancePage />
//       </ProtectedRoute>
//     }
//   />
