// ─── pages/AdminPermissionsPage.jsx ─────────────────────────────────────────
//
// Admin kullanıcısına özel izin yönetim paneli.
// Yalnızca admin grubundaki kullanıcılar erişebilir.
//
// React Router v6 ile app.jsx'te şu şekilde kullanılır:
//   <ProtectedRoute page="settings" group={currentUser.group}>
//     <AdminPermissionsPage />
//   </ProtectedRoute>

import { useState } from 'react';
import { usePermissions } from '../permissions/PermissionsContext';

// ─── Metadata (sadece görsel etiketler) ──────────────────────────────────────

const PAGE_META = {
  dashboard:    { name: 'Dashboard',        desc: 'Ana ekran & özet metrikler' },
  analytics:    { name: 'Analitik',          desc: 'Grafik ve raporlar' },
  users:        { name: 'Kullanıcılar',      desc: 'Kullanıcı listesi & yönetim' },
  settings:     { name: 'Ayarlar',           desc: 'Sistem yapılandırması' },
  products:     { name: 'Ürünler',           desc: 'Ürün kataloğu' },
  orders:       { name: 'Siparişler',        desc: 'Sipariş takibi' },
  finance:      { name: 'Finans',            desc: 'Gelir & gider raporları' },
  support:      { name: 'Destek',            desc: 'Müşteri talepleri' },
  logs:         { name: 'Denetim Logları',   desc: 'Sistem aktivite kayıtları' },
  integrations: { name: 'Entegrasyonlar',    desc: 'API & bağlantı yönetimi' },
};

const COMPONENT_META = {
  revenueWidget: { name: 'Gelir Bileşeni',    desc: 'Gelir kartı & trend grafiği' },
  userTable:     { name: 'Kullanıcı Tablosu', desc: 'Tam liste görünümü' },
  exportBtn:     { name: 'Dışa Aktar',        desc: 'CSV / Excel indirme' },
  adminMenu:     { name: 'Yönetici Menüsü',   desc: 'Üst bar yönetici seçenekleri' },
  deleteBtn:     { name: 'Silme Butonu',      desc: 'Kayıt silme işlemi' },
  bulkActions:   { name: 'Toplu İşlem',       desc: 'Çoklu kayıt seçimi' },
  priceColumn:   { name: 'Fiyat Kolonu',      desc: 'Ürün fiyat bilgisi' },
  contactInfo:   { name: 'İletişim Bilgisi',  desc: 'E-posta & telefon' },
};

const CRUD_META = {
  users:      { name: 'Kullanıcılar',  desc: 'Kullanıcı kayıtları' },
  products:   { name: 'Ürünler',       desc: 'Ürün veritabanı' },
  orders:     { name: 'Siparişler',    desc: 'Sipariş kayıtları' },
  categories: { name: 'Kategoriler',   desc: 'Ürün kategorileri' },
  reports:    { name: 'Raporlar',      desc: 'Analitik raporlar' },
  settings:   { name: 'Ayarlar',       desc: 'Sistem yapılandırma' },
  invoices:   { name: 'Faturalar',     desc: 'Fatura kayıtları' },
};

const DATA_META = {
  allUsers:        { name: 'Tüm kullanıcılar',  desc: 'Sistemdeki tüm kayıtlar' },
  ownData:         { name: 'Kendi verileri',     desc: 'Sadece kendi kayıtları' },
  teamData:        { name: 'Ekip verileri',      desc: 'Aynı takım üyeleri' },
  financialData:   { name: 'Finansal veriler',   desc: 'Gelir & maliyet bilgileri' },
  personalInfo:    { name: 'Kişisel bilgiler',   desc: 'Ad, iletişim detayları' },
  sensitiveReports:{ name: 'Hassas raporlar',    desc: 'Gizli analiz verileri' },
  archivedData:    { name: 'Arşiv verileri',     desc: 'Eski & pasif kayıtlar' },
};

const CRUD_OPS = [
  { op: 'c', label: 'Oluştur' },
  { op: 'r', label: 'Oku' },
  { op: 'u', label: 'Güncelle' },
  { op: 'd', label: 'Sil' },
];

const TABS = ['pages', 'components', 'crud', 'data'];
const TAB_LABELS = {
  pages: 'Sayfa Erişimi',
  components: 'Bileşen Görünürlüğü',
  crud: 'İşlem Yetkileri',
  data: 'Veri Kapsamı',
};

// ─── Styles (inline — Tailwind olmadan da çalışır) ────────────────────────────

const S = {
  shell: {
    display: 'flex', height: '100vh', fontFamily: "'IBM Plex Sans', sans-serif",
    fontSize: 13, color: '#111827', background: '#F4F6F9',
  },
  sidebar: {
    width: 210, background: '#fff', borderRight: '1px solid #DDE2EA',
    display: 'flex', flexDirection: 'column', flexShrink: 0,
  },
  sbTop: { padding: '14px 14px 12px', borderBottom: '1px solid #DDE2EA' },
  logo: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 },
  logoMark: {
    width: 22, height: 22, background: '#1E40AF', borderRadius: 3,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
  logoText: { fontSize: 12, fontWeight: 600, color: '#111827' },
  sbLabel: { fontSize: 9, fontWeight: 600, color: '#9CA3AF', letterSpacing: '.1em', textTransform: 'uppercase' },
  sbBody: { padding: '12px 8px', display: 'flex', flexDirection: 'column', gap: 4 },
  sbNote: {
    padding: '8px 10px', fontSize: 10, color: '#9CA3AF', lineHeight: 1.5,
    borderTop: '1px solid #DDE2EA', marginTop: 'auto',
  },
  main: { flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' },
  topbar: {
    background: '#fff', borderBottom: '1px solid #DDE2EA',
    padding: '0 22px', display: 'flex', alignItems: 'center', gap: 12, height: 52, flexShrink: 0,
  },
  tabrow: {
    background: '#fff', borderBottom: '1px solid #DDE2EA',
    padding: '0 22px', display: 'flex', flexShrink: 0,
  },
  content: { flex: 1, overflowY: 'auto', padding: '18px 22px', background: '#F4F6F9' },
  table: {
    width: '100%', borderCollapse: 'collapse', background: '#fff',
    border: '1px solid #DDE2EA', borderRadius: 4, overflow: 'hidden', marginBottom: 18,
  },
  th: {
    fontSize: 9, fontWeight: 600, color: '#9CA3AF', letterSpacing: '.08em',
    textTransform: 'uppercase', padding: '7px 14px',
    background: '#F8F9FB', borderBottom: '1px solid #DDE2EA', textAlign: 'left',
  },
  tr: { borderBottom: '1px solid #DDE2EA', transition: 'background .1s' },
  td: { padding: '9px 14px', borderRight: '1px solid #DDE2EA', verticalAlign: 'middle' },
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function GroupButton({ groupKey, activeGroup, onSelect }) {
  const isAdmin = groupKey === 'admin';
  const isActive = activeGroup === groupKey;
  const color = isAdmin ? '#1E40AF' : '#065F46';
  const bg = isAdmin ? '#EFF4FF' : '#ECFDF5';
  const border = isActive
    ? `1.5px solid ${isAdmin ? '#BFDBFE' : '#A7F3D0'}`
    : '1.5px solid transparent';
  const activeBg = isActive ? bg : 'transparent';

  return (
    <div
      onClick={() => onSelect(groupKey)}
      style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '9px 10px', borderRadius: 4, cursor: 'pointer',
        border, background: activeBg, transition: 'all .12s',
      }}
    >
      <div style={{
        width: 34, height: 34, borderRadius: 4, background: bg, color,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 10, fontWeight: 700, fontFamily: 'IBM Plex Mono, monospace', flexShrink: 0,
      }}>
        {isAdmin ? 'ADM' : 'USR'}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: '#111827' }}>
          {isAdmin ? 'Admin Grubu' : 'User Grubu'}
        </div>
        <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>
          {isAdmin ? '6 üye · Tam yetkili' : '24 üye · Standart'}
        </div>
      </div>
      <div style={{
        fontSize: 9, fontWeight: 600, fontFamily: 'IBM Plex Mono, monospace',
        padding: '2px 6px', borderRadius: 10, border: `1px solid ${isAdmin ? '#BFDBFE' : '#A7F3D0'}`,
        background: bg, color,
      }}>
        {isAdmin ? '6' : '24'}
      </div>
    </div>
  );
}

function Toggle({ checked, onChange, isAdmin }) {
  return (
    <label style={{ position: 'relative', width: 30, height: 17, cursor: 'pointer', display: 'inline-block' }}>
      <input type="checkbox" checked={checked} onChange={onChange}
        style={{ opacity: 0, width: 0, height: 0, position: 'absolute' }} />
      <div style={{
        position: 'absolute', inset: 0, borderRadius: 9,
        background: checked ? (isAdmin ? '#1E40AF' : '#065F46') : '#D1D5DB',
        transition: 'background .18s',
      }} />
      <div style={{
        position: 'absolute', top: 3, left: 3, width: 11, height: 11,
        background: '#fff', borderRadius: '50%',
        transform: checked ? 'translateX(13px)' : 'none',
        transition: 'transform .18s',
        boxShadow: '0 1px 2px rgba(0,0,0,.2)',
      }} />
    </label>
  );
}

function SectionHead({ title, count }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 9 }}>
      <span style={{ fontSize: 9, fontWeight: 600, color: '#9CA3AF', letterSpacing: '.1em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
        {title}
      </span>
      <div style={{ flex: 1, height: 1, background: '#DDE2EA' }} />
      <span style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: '#9CA3AF', background: '#F8F9FB', border: '1px solid #DDE2EA', padding: '1px 5px', borderRadius: 2 }}>
        {count}
      </span>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function AdminPermissionsPage() {
  const { permissions, togglePerm, toggleCrud, resetGroup } = usePermissions();
  const [activeGroup, setActiveGroup] = useState('admin');
  const [activeTab, setActiveTab]     = useState('pages');
  const [saved, setSaved]             = useState(false);
  const isAdmin = activeGroup === 'admin';

  const grpPerms = permissions[activeGroup];

  const handleSave = () => {
    // localStorage'a zaten otomatik yazıyor (PermissionsContext).
    // Burada API çağrısı yapılabilir:
    // await api.post('/permissions', permissions);
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  };

  // ── Render helpers ──────────────────────────────────────────────────────────

  const renderPages = () => {
    const entries = Object.entries(grpPerms.pages);
    const on  = entries.filter(([, v]) => v.on);
    const off = entries.filter(([, v]) => !v.on);

    const tableBlock = (rows, title) => rows.length === 0 ? null : (
      <>
        <SectionHead title={title} count={rows.length} />
        <table style={S.table}>
          <thead><tr>
            <th style={S.th}>Sayfa</th>
            <th style={{ ...S.th, textAlign: 'center', width: 110 }}>İzin</th>
          </tr></thead>
          <tbody>
            {rows.map(([key]) => (
              <tr key={key} style={S.tr}>
                <td style={S.td}>
                  <div style={{ fontSize: 12, fontWeight: 500 }}>{PAGE_META[key]?.name}</div>
                  <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>{PAGE_META[key]?.desc}</div>
                </td>
                <td style={{ ...S.td, textAlign: 'center', borderRight: 'none' }}>
                  <Toggle
                    checked={grpPerms.pages[key].on}
                    onChange={() => togglePerm(activeGroup, 'pages', key)}
                    isAdmin={isAdmin}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </>
    );

    return (
      <>
        {tableBlock(on,  'Erişim Açık')}
        {tableBlock(off, 'Erişim Kapalı')}
      </>
    );
  };

  const renderComponents = () => {
    const entries = Object.entries(grpPerms.components);
    const on  = entries.filter(([, v]) => v.on);
    const off = entries.filter(([, v]) => !v.on);

    const tableBlock = (rows, title) => rows.length === 0 ? null : (
      <>
        <SectionHead title={title} count={rows.length} />
        <table style={S.table}>
          <thead><tr>
            <th style={S.th}>Bileşen</th>
            <th style={{ ...S.th, textAlign: 'center', width: 110 }}>Görünürlük</th>
          </tr></thead>
          <tbody>
            {rows.map(([key]) => (
              <tr key={key} style={S.tr}>
                <td style={S.td}>
                  <div style={{ fontSize: 12, fontWeight: 500 }}>{COMPONENT_META[key]?.name}</div>
                  <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>{COMPONENT_META[key]?.desc}</div>
                </td>
                <td style={{ ...S.td, textAlign: 'center', borderRight: 'none' }}>
                  <Toggle
                    checked={grpPerms.components[key].on}
                    onChange={() => togglePerm(activeGroup, 'components', key)}
                    isAdmin={isAdmin}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </>
    );

    return (
      <>
        {tableBlock(on,  'Görünür Bileşenler')}
        {tableBlock(off, 'Gizli Bileşenler')}
      </>
    );
  };

  const renderCrud = () => {
    const opColors = {
      c: { on: { bg: '#D1FAE5', border: '#6EE7B7', color: '#065F46' } },
      r: { on: { bg: '#DBEAFE', border: '#93C5FD', color: '#1E40AF' } },
      u: { on: { bg: '#FEF3C7', border: '#FCD34D', color: '#92400E' } },
      d: { on: { bg: '#FEE2E2', border: '#FCA5A5', color: '#991B1B' } },
    };

    return (
      <>
        <SectionHead title="İşlem Yetkileri" count={Object.keys(grpPerms.crud).length} />
        <div style={{ background: '#fff', border: '1px solid #DDE2EA', borderRadius: 4, overflow: 'hidden', marginBottom: 18 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ ...S.th, width: 160 }}>Kaynak</th>
                {CRUD_OPS.map(({ op, label }) => (
                  <th key={op} style={{ ...S.th, textAlign: 'center', width: 80 }}>{label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Object.entries(grpPerms.crud).map(([resource, ops]) => (
                <tr key={resource} style={S.tr}>
                  <td style={S.td}>
                    <div style={{ fontSize: 12, fontWeight: 500 }}>{CRUD_META[resource]?.name}</div>
                    <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>{CRUD_META[resource]?.desc}</div>
                  </td>
                  {CRUD_OPS.map(({ op }) => {
                    const active = ops[op];
                    const col = opColors[op].on;
                    return (
                      <td key={op} style={{ ...S.td, textAlign: 'center' }}>
                        <div
                          onClick={() => toggleCrud(activeGroup, resource, op)}
                          style={{
                            width: 22, height: 22, borderRadius: 3, margin: '0 auto',
                            border: `1px solid ${active ? col.border : '#DDE2EA'}`,
                            background: active ? col.bg : '#fff',
                            color: active ? col.color : '#9CA3AF',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            cursor: 'pointer', fontSize: 10, fontWeight: 700,
                            fontFamily: 'IBM Plex Mono, monospace',
                            transition: 'all .12s',
                          }}
                        >
                          {active ? '✓' : '—'}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    );
  };

  const renderData = () => {
    const entries = Object.entries(grpPerms.data);
    const on  = entries.filter(([, v]) => v.on);
    const off = entries.filter(([, v]) => !v.on);

    const tableBlock = (rows, title) => rows.length === 0 ? null : (
      <>
        <SectionHead title={title} count={rows.length} />
        <table style={S.table}>
          <thead><tr>
            <th style={S.th}>Veri Kapsamı</th>
            <th style={{ ...S.th, textAlign: 'center', width: 110 }}>Erişim</th>
          </tr></thead>
          <tbody>
            {rows.map(([key]) => (
              <tr key={key} style={S.tr}>
                <td style={S.td}>
                  <div style={{ fontSize: 12, fontWeight: 500 }}>{DATA_META[key]?.name}</div>
                  <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>{DATA_META[key]?.desc}</div>
                </td>
                <td style={{ ...S.td, textAlign: 'center', borderRight: 'none' }}>
                  <Toggle
                    checked={grpPerms.data[key].on}
                    onChange={() => togglePerm(activeGroup, 'data', key)}
                    isAdmin={isAdmin}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </>
    );

    return (
      <>
        {tableBlock(on,  'Erişilebilir Veri')}
        {tableBlock(off, 'Erişim Yok')}
      </>
    );
  };

  const tabContent = {
    pages:      renderPages,
    components: renderComponents,
    crud:       renderCrud,
    data:       renderData,
  };

  // ── Render ──────────────────────────────────────────────────────────────────

  const accentColor = isAdmin ? '#1E40AF' : '#065F46';
  const accentBg    = isAdmin ? '#EFF4FF' : '#ECFDF5';
  const accentMid   = isAdmin ? '#BFDBFE' : '#A7F3D0';

  return (
    <div style={S.shell}>
      {/* SIDEBAR */}
      <div style={S.sidebar}>
        <div style={S.sbTop}>
          <div style={S.logo}>
            <div style={S.logoMark}>
              <svg width="13" height="13" viewBox="0 0 16 16" fill="white">
                <path d="M8 1L1 5v6l7 4 7-4V5L8 1zm0 2.2L13 6.3v4.4L8 13.4 3 10.7V6.3L8 3.2z" />
              </svg>
            </div>
            <span style={S.logoText}>AccessControl</span>
          </div>
          <div style={S.sbLabel}>Grup Yetki Yönetimi</div>
        </div>

        <div style={S.sbBody}>
          {['admin', 'user'].map((g) => (
            <GroupButton key={g} groupKey={g} activeGroup={activeGroup} onSelect={setActiveGroup} />
          ))}

          <div style={{ height: 1, background: '#DDE2EA', margin: '8px 0' }} />

          {/* Özet */}
          <div style={{ background: '#F8F9FB', border: '1px solid #DDE2EA', borderRadius: 4, overflow: 'hidden' }}>
            {(['admin', 'user']).map((g, i) => {
              const total = Object.keys(permissions[g].pages).length;
              const open  = Object.values(permissions[g].pages).filter(v => v.on).length;
              const color = g === 'admin' ? '#1E40AF' : '#065F46';
              return (
                <div key={g} style={{
                  display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px',
                  borderBottom: i === 0 ? '1px solid #DDE2EA' : 'none',
                }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: color, flexShrink: 0 }} />
                  <span style={{ fontSize: 11, color: '#4B5563', flex: 1 }}>{g === 'admin' ? 'Admin' : 'User'}</span>
                  <span style={{ fontSize: 10, fontFamily: 'IBM Plex Mono, monospace', color }}>
                    {open}/{total} sayfa
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div style={S.sbNote}>
          <strong style={{ color: '#4B5563', fontWeight: 500 }}>Not:</strong> Değişiklikler kaydedildiğinde gruptaki tüm üyelere uygulanır.
        </div>
      </div>

      {/* MAIN */}
      <div style={S.main}>
        {/* Topbar */}
        <div style={S.topbar}>
          <div style={{
            width: 32, height: 32, borderRadius: 4,
            background: accentBg, color: accentColor,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 10, fontWeight: 700, fontFamily: 'IBM Plex Mono, monospace',
          }}>
            {isAdmin ? 'ADM' : 'USR'}
          </div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>
              {isAdmin ? 'Admin Grubu' : 'User Grubu'}
            </div>
            <div style={{ fontSize: 10, color: '#9CA3AF', marginTop: 1 }}>
              {isAdmin ? '6 üye · Tam yetkili yöneticiler' : '24 üye · Standart kullanıcılar'}
            </div>
          </div>
          <div style={{
            fontSize: 9, fontWeight: 600, letterSpacing: '.06em', textTransform: 'uppercase',
            padding: '2px 8px', borderRadius: 2, border: `1px solid ${accentMid}`,
            background: accentBg, color: accentColor, fontFamily: 'IBM Plex Mono, monospace',
          }}>
            {isAdmin ? 'ADMİN GRUBU' : 'USER GRUBU'}
          </div>

          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <button
              onClick={() => resetGroup(activeGroup)}
              style={{
                background: '#fff', border: '1px solid #C8D0DC', borderRadius: 3,
                padding: '5px 12px', fontSize: 11, fontWeight: 500, cursor: 'pointer',
                fontFamily: "'IBM Plex Sans', sans-serif", color: '#4B5563',
              }}
            >
              Sıfırla
            </button>
            <button
              onClick={handleSave}
              style={{
                background: saved ? '#065F46' : '#1E40AF',
                border: 'none', borderRadius: 3,
                padding: '5px 14px', fontSize: 11, fontWeight: 500, cursor: 'pointer',
                fontFamily: "'IBM Plex Sans', sans-serif", color: '#fff',
                transition: 'background .2s',
              }}
            >
              {saved ? 'Kaydedildi ✓' : 'Kaydet'}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div style={S.tabrow}>
          {TABS.map((t) => (
            <div
              key={t}
              onClick={() => setActiveTab(t)}
              style={{
                padding: '10px 14px', fontSize: 11, fontWeight: activeTab === t ? 600 : 500,
                color: activeTab === t ? '#1E40AF' : '#9CA3AF',
                borderBottom: `2px solid ${activeTab === t ? '#1E40AF' : 'transparent'}`,
                marginBottom: -1, cursor: 'pointer', whiteSpace: 'nowrap',
                transition: 'all .12s',
              }}
            >
              {TAB_LABELS[t]}
            </div>
          ))}
        </div>

        {/* Content */}
        <div style={S.content}>
          {tabContent[activeTab]?.()}
        </div>
      </div>
    </div>
  );
}
