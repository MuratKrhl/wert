// ─── permissions/ProtectedRoute.jsx ─────────────────────────────────────────
//
// React Router v6 ile çalışır.
// Kullanıcının grubu (role) ve hedef sayfa key'i verilir;
// izin yoksa fallback'e yönlendirir.
//
// Kullanım:
//   <ProtectedRoute page="analytics" group={currentUser.group}>
//     <AnalyticsPage />
//   </ProtectedRoute>

import { Navigate } from 'react-router-dom';
import { usePermissions } from './PermissionsContext';

/**
 * @param {object} props
 * @param {string}        props.page       — permissionsConfig'deki sayfa key'i
 * @param {'admin'|'user'} props.group     — oturum açmış kullanıcının grubu
 * @param {string}        [props.fallback] — izin yoksa yönlendirilecek path (default: '/')
 * @param {React.ReactNode} props.children
 */
export function ProtectedRoute({ page, group, fallback = '/', children }) {
  const { canAccessPage } = usePermissions();

  if (!canAccessPage(group, page)) {
    return <Navigate to={fallback} replace />;
  }

  return children;
}
