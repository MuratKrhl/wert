// ─── App.jsx — Entegrasyon Örneği ────────────────────────────────────────────
//
// PermissionsProvider tüm uygulamayı sarar.
// currentUser.group değeri auth sisteminden gelir ('admin' | 'user').

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { PermissionsProvider } from './permissions/PermissionsContext';
import { ProtectedRoute }      from './permissions/ProtectedRoute';
import AdminPermissionsPage    from './pages/AdminPermissionsPage';

// Örnek sayfalar — kendi sayfalarınızla değiştirin
import DashboardPage    from './pages/DashboardPage';
import AnalyticsPage    from './pages/AnalyticsPage';
import UsersPage        from './pages/UsersPage';
import FinancePage      from './pages/FinancePage';

// Auth hook'unuzdan gelen kullanıcı (örnek)
// { id, name, group: 'admin' | 'user' }
function useCurrentUser() {
  // Gerçek uygulamada: useAuth(), useSelector(state => state.auth.user), vb.
  return { id: 1, name: 'Ayşe Kaya', group: 'admin' };
}

export default function App() {
  const currentUser = useCurrentUser();
  const g = currentUser.group; // 'admin' | 'user'

  return (
    <PermissionsProvider>
      <BrowserRouter>
        <Routes>

          {/* Her kullanıcı dashboard'a erişebilir */}
          <Route path="/" element={<DashboardPage />} />

          {/* Korumalı sayfalar — izin yoksa '/' e yönlendirir */}
          <Route
            path="/analytics"
            element={
              <ProtectedRoute page="analytics" group={g}>
                <AnalyticsPage />
              </ProtectedRoute>
            }
          />

          <Route
            path="/users"
            element={
              <ProtectedRoute page="users" group={g}>
                <UsersPage />
              </ProtectedRoute>
            }
          />

          <Route
            path="/finance"
            element={
              <ProtectedRoute page="finance" group={g}>
                <FinancePage />
              </ProtectedRoute>
            }
          />

          {/* Admin paneli — sadece admin grubuna açık */}
          <Route
            path="/admin/permissions"
            element={
              <ProtectedRoute page="settings" group={g} fallback="/">
                <AdminPermissionsPage />
              </ProtectedRoute>
            }
          />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </PermissionsProvider>
  );
}
