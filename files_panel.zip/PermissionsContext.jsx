// ─── permissions/PermissionsContext.jsx ─────────────────────────────────────
import { createContext, useContext, useReducer, useEffect } from 'react';
import { DEFAULT_PERMISSIONS, STORAGE_KEY } from './permissionsConfig';

// ─── Helpers ─────────────────────────────────────────────────────────────────

function loadFromStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveToStorage(perms) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(perms));
  } catch {
    // storage unavailable — silently ignore
  }
}

// Deep merge: stored değerleri default üzerine uygular.
// Yeni izin eklense bile eski storage'ı bozmaz.
function mergeWithDefaults(stored) {
  const result = {};
  for (const group of ['admin', 'user']) {
    result[group] = {};
    for (const section of ['pages', 'components', 'crud', 'data']) {
      result[group][section] = {
        ...DEFAULT_PERMISSIONS[group][section],
        ...(stored?.[group]?.[section] ?? {}),
      };
    }
  }
  return result;
}

// ─── Reducer ─────────────────────────────────────────────────────────────────

function reducer(state, action) {
  switch (action.type) {

    case 'TOGGLE_PERM': {
      const { group, section, key } = action.payload;
      const prev = state[group][section][key];
      return {
        ...state,
        [group]: {
          ...state[group],
          [section]: {
            ...state[group][section],
            [key]: { ...prev, on: !prev.on },
          },
        },
      };
    }

    case 'TOGGLE_CRUD': {
      const { group, resource, op } = action.payload;
      const prev = state[group].crud[resource];
      return {
        ...state,
        [group]: {
          ...state[group],
          crud: {
            ...state[group].crud,
            [resource]: { ...prev, [op]: !prev[op] },
          },
        },
      };
    }

    case 'RESET_GROUP': {
      const { group } = action.payload;
      return {
        ...state,
        [group]: DEFAULT_PERMISSIONS[group],
      };
    }

    case 'RESET_ALL':
      return mergeWithDefaults(null);

    default:
      return state;
  }
}

// ─── Context ─────────────────────────────────────────────────────────────────

const PermissionsContext = createContext(null);

export function PermissionsProvider({ children }) {
  const [permissions, dispatch] = useReducer(
    reducer,
    mergeWithDefaults(loadFromStorage())
  );

  // Her değişiklikte localStorage'a yaz
  useEffect(() => {
    saveToStorage(permissions);
  }, [permissions]);

  // ── Action helpers ──────────────────────────────────────────────────────────

  /** Sayfa / bileşen / veri kapsamı toggle'ı */
  const togglePerm = (group, section, key) =>
    dispatch({ type: 'TOGGLE_PERM', payload: { group, section, key } });

  /** CRUD işlem toggle'ı */
  const toggleCrud = (group, resource, op) =>
    dispatch({ type: 'TOGGLE_CRUD', payload: { group, resource, op } });

  /** Tek grup için varsayılana sıfırla */
  const resetGroup = (group) =>
    dispatch({ type: 'RESET_GROUP', payload: { group } });

  /** Tüm izinleri varsayılana sıfırla */
  const resetAll = () => dispatch({ type: 'RESET_ALL' });

  // ── Query helpers ───────────────────────────────────────────────────────────

  /**
   * Kullanıcının belirtilen sayfaya erişimi var mı?
   * @param {'admin'|'user'} group
   * @param {string} page  — permissionsConfig'deki key
   */
  const canAccessPage = (group, page) =>
    permissions[group]?.pages?.[page]?.on ?? false;

  /**
   * Kullanıcı belirtilen bileşeni görebilir mi?
   */
  const canSeeComponent = (group, component) =>
    permissions[group]?.components?.[component]?.on ?? false;

  /**
   * Belirtilen kaynak üzerinde CRUD işlemi yapabilir mi?
   * @param {'c'|'r'|'u'|'d'} op
   */
  const canDo = (group, resource, op) =>
    permissions[group]?.crud?.[resource]?.[op] ?? false;

  /**
   * Belirtilen veri kapsamına erişimi var mı?
   */
  const canAccessData = (group, scope) =>
    permissions[group]?.data?.[scope]?.on ?? false;

  const value = {
    permissions,
    togglePerm,
    toggleCrud,
    resetGroup,
    resetAll,
    // Query helpers
    canAccessPage,
    canSeeComponent,
    canDo,
    canAccessData,
  };

  return (
    <PermissionsContext.Provider value={value}>
      {children}
    </PermissionsContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

/**
 * Herhangi bir bileşenden izin sistemine erişim.
 *
 * @example
 * const { canAccessPage, canDo } = usePermissions();
 * if (!canAccessPage('user', 'analytics')) return <Redirect to="/" />;
 */
export function usePermissions() {
  const ctx = useContext(PermissionsContext);
  if (!ctx) {
    throw new Error('usePermissions must be used inside <PermissionsProvider>');
  }
  return ctx;
}
