// ─── permissions/permissionsConfig.js ────────────────────────────────────────
// Tüm izin tanımları burada merkezi olarak yönetilir.
// Admin panelindeki toggle'lar bu objeyi günceller.

export const DEFAULT_PERMISSIONS = {
  admin: {
    pages: {
      dashboard:    { on: true },
      analytics:    { on: true },
      users:        { on: true },
      settings:     { on: true },
      products:     { on: true },
      orders:       { on: true },
      finance:      { on: true },
      support:      { on: true },
      logs:         { on: true },
      integrations: { on: true },
    },
    components: {
      revenueWidget: { on: true },
      userTable:     { on: true },
      exportBtn:     { on: true },
      adminMenu:     { on: true },
      deleteBtn:     { on: true },
      bulkActions:   { on: true },
      priceColumn:   { on: true },
      contactInfo:   { on: true },
    },
    crud: {
      users:      { c: true,  r: true,  u: true,  d: true  },
      products:   { c: true,  r: true,  u: true,  d: true  },
      orders:     { c: true,  r: true,  u: true,  d: true  },
      categories: { c: true,  r: true,  u: true,  d: true  },
      reports:    { c: true,  r: true,  u: true,  d: true  },
      settings:   { c: true,  r: true,  u: true,  d: false },
      invoices:   { c: true,  r: true,  u: true,  d: false },
    },
    data: {
      allUsers:        { on: true  },
      ownData:         { on: true  },
      teamData:        { on: true  },
      financialData:   { on: true  },
      personalInfo:    { on: true  },
      sensitiveReports:{ on: true  },
      archivedData:    { on: true  },
    },
  },

  user: {
    pages: {
      dashboard:    { on: true  },
      analytics:    { on: false },
      users:        { on: false },
      settings:     { on: false },
      products:     { on: true  },
      orders:       { on: true  },
      finance:      { on: false },
      support:      { on: true  },
      logs:         { on: false },
      integrations: { on: false },
    },
    components: {
      revenueWidget: { on: false },
      userTable:     { on: false },
      exportBtn:     { on: false },
      adminMenu:     { on: false },
      deleteBtn:     { on: false },
      bulkActions:   { on: false },
      priceColumn:   { on: true  },
      contactInfo:   { on: true  },
    },
    crud: {
      users:      { c: false, r: false, u: false, d: false },
      products:   { c: false, r: true,  u: false, d: false },
      orders:     { c: true,  r: true,  u: true,  d: false },
      categories: { c: false, r: true,  u: false, d: false },
      reports:    { c: false, r: true,  u: false, d: false },
      settings:   { c: false, r: false, u: false, d: false },
      invoices:   { c: false, r: true,  u: false, d: false },
    },
    data: {
      allUsers:        { on: false },
      ownData:         { on: true  },
      teamData:        { on: false },
      financialData:   { on: false },
      personalInfo:    { on: false },
      sensitiveReports:{ on: false },
      archivedData:    { on: false },
    },
  },
};

// localStorage key
export const STORAGE_KEY = 'app_permissions_v1';
