from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken

from .serializers import LoginSerializer, UserSerializer


def get_tokens_for_user(user):
    """Kullanıcı için JWT token üret."""
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class LoginView(APIView):
    """
    POST /api/auth/login/
    LDAP/AD veya local DB ile giriş yapar, JWT token döner.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            tokens = get_tokens_for_user(user)
            user_data = UserSerializer(user).data
            return Response({
                'success': True,
                'user': user_data,
                'tokens': tokens,
            }, status=status.HTTP_200_OK)

        return Response({
            'success': False,
            'errors': serializer.errors,
        }, status=status.HTTP_401_UNAUTHORIZED)


class LogoutView(APIView):
    """
    POST /api/auth/logout/
    Refresh token'ı blacklist'e ekler.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data.get('refresh')
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response({'success': True, 'message': 'Çıkış yapıldı.'})
        except Exception:
            return Response(
                {'success': False, 'message': 'Token geçersiz.'},
                status=status.HTTP_400_BAD_REQUEST
            )


class MeView(APIView):
    """
    GET /api/auth/me/
    Giriş yapan kullanıcının bilgilerini döner.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response({
            'success': True,
            'user': serializer.data,
        })


class LDAPTestView(APIView):
    """
    GET /api/auth/ldap-test/
    LDAP bağlantısını test eder (sadece admin kullanabilir).
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not request.user.is_staff:
            return Response({'error': 'Yetkisiz erişim.'}, status=403)

        import ldap
        from django.conf import settings

        try:
            conn = ldap.initialize(settings.AUTH_LDAP_SERVER_URI)
            conn.simple_bind_s(
                settings.AUTH_LDAP_BIND_DN,
                settings.AUTH_LDAP_BIND_PASSWORD
            )
            conn.unbind_s()
            return Response({
                'success': True,
                'message': 'LDAP bağlantısı başarılı.',
                'server': settings.AUTH_LDAP_SERVER_URI,
            })
        except ldap.INVALID_CREDENTIALS:
            return Response({'success': False, 'error': 'LDAP kimlik bilgileri hatalı.'}, status=400)
        except ldap.SERVER_DOWN:
            return Response({'success': False, 'error': 'LDAP sunucusuna ulaşılamıyor.'}, status=503)
        except Exception as e:
            return Response({'success': False, 'error': str(e)}, status=500)
