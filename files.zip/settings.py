"""
Django Settings - Dashboard Backend
MSSQL + LDAP/Active Directory Entegrasyonu
"""

from pathlib import Path
from decouple import config
from datetime import timedelta

BASE_DIR = Path(__file__).resolve().parent.parent

# ─────────────────────────────────────────────
# TEMEL AYARLAR
# ─────────────────────────────────────────────
SECRET_KEY = config('SECRET_KEY', default='change-me-in-production')
DEBUG = config('DEBUG', default=False, cast=bool)
ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost').split(',')

# ─────────────────────────────────────────────
# UYGULAMALAR
# ─────────────────────────────────────────────
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # Third-party
    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',
    # Local apps
    'apps.authentication',
    'apps.api',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'
WSGI_APPLICATION = 'config.wsgi.application'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# ─────────────────────────────────────────────
# MİCROSOFT SQL SERVER VERİTABANI
# ─────────────────────────────────────────────
DATABASES = {
    'default': {
        'ENGINE': 'mssql',
        'NAME': config('DB_NAME', default='dashboard_db'),
        'USER': config('DB_USER', default='sa'),
        'PASSWORD': config('DB_PASSWORD', default=''),
        'HOST': config('DB_HOST', default='localhost'),
        'PORT': config('DB_PORT', default='1433'),
        'OPTIONS': {
            'driver': 'ODBC Driver 18 for SQL Server',
            'extra_params': 'TrustServerCertificate=yes',
        },
    }
}

# ─────────────────────────────────────────────
# LDAP / ACTIVE DIRECTORY AUTHENTICATION
# ─────────────────────────────────────────────
import ldap
from django_auth_ldap.config import LDAPSearch, GroupOfNamesType, ActiveDirectoryGroupType

# LDAP bağlantı ayarları
AUTH_LDAP_SERVER_URI = config('LDAP_SERVER_URI', default='ldap://localhost')
AUTH_LDAP_BIND_DN = config('LDAP_BIND_DN', default='')
AUTH_LDAP_BIND_PASSWORD = config('LDAP_BIND_PASSWORD', default='')

# TLS/SSL ayarları (production'da True yapın)
AUTH_LDAP_CONNECTION_OPTIONS = {
    ldap.OPT_REFERRALS: 0,
    ldap.OPT_X_TLS_REQUIRE_CERT: ldap.OPT_X_TLS_NEVER,
}

# Kullanıcı arama
AUTH_LDAP_USER_SEARCH = LDAPSearch(
    config('LDAP_USER_SEARCH_OU', default='DC=company,DC=com'),
    ldap.SCOPE_SUBTREE,
    '(sAMAccountName=%(user)s)',  # Active Directory için
)

# Grup arama
AUTH_LDAP_GROUP_SEARCH = LDAPSearch(
    config('LDAP_GROUP_SEARCH_OU', default='DC=company,DC=com'),
    ldap.SCOPE_SUBTREE,
    '(objectClass=group)',
)
AUTH_LDAP_GROUP_TYPE = ActiveDirectoryGroupType()

# AD kullanıcı özelliklerini Django alanlarıyla eşleştir
AUTH_LDAP_USER_ATTR_MAP = {
    'first_name': 'givenName',
    'last_name': 'sn',
    'email': 'mail',
}

# Kullanıcı flag'leri
AUTH_LDAP_USER_FLAGS_BY_GROUP = {
    'is_active': config('LDAP_GROUP_SEARCH_OU', default='DC=company,DC=com'),
    # İstersen admin grubunu buraya ekleyebilirsin:
    # 'is_staff': 'CN=Django Admins,OU=Groups,DC=company,DC=com',
}

# Her login'de LDAP gruplarını güncelle
AUTH_LDAP_ALWAYS_UPDATE_USER = True
AUTH_LDAP_FIND_GROUP_PERMS = True
AUTH_LDAP_CACHE_TIMEOUT = 3600

# ─────────────────────────────────────────────
# AUTHENTICATION BACKENDS
# (önce LDAP dene, başarısız olursa local DB)
# ─────────────────────────────────────────────
AUTHENTICATION_BACKENDS = [
    'django_auth_ldap.backend.LDAPBackend',
    'django.contrib.auth.backends.ModelBackend',
]

# ─────────────────────────────────────────────
# JWT (SIMPLEJWT) AYARLARI
# ─────────────────────────────────────────────
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    ),
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(hours=8),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'ALGORITHM': 'HS256',
    'AUTH_HEADER_TYPES': ('Bearer',),
}

# ─────────────────────────────────────────────
# CORS (React frontend için)
# ─────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = config(
    'CORS_ALLOWED_ORIGINS',
    default='http://localhost:3000'
).split(',')
CORS_ALLOW_CREDENTIALS = True

# ─────────────────────────────────────────────
# DİĞER AYARLAR
# ─────────────────────────────────────────────
LANGUAGE_CODE = 'tr-tr'
TIME_ZONE = 'Europe/Istanbul'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Logging - LDAP debug için
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {'class': 'logging.StreamHandler'},
        'file': {
            'class': 'logging.FileHandler',
            'filename': 'django.log',
        },
    },
    'loggers': {
        'django_auth_ldap': {
            'level': 'DEBUG' if DEBUG else 'WARNING',
            'handlers': ['console', 'file'],
        },
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
        },
    },
}
