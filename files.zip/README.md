# Dashboard Backend
Django + Microsoft SQL Server + LDAP/Active Directory

## Kurulum

### 1. Virtual Environment Oluştur
```bash
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows
```

### 2. ODBC Driver Kur (MSSQL için zorunlu)
**Windows:** Microsoft'tan "ODBC Driver 18 for SQL Server" indir
**Ubuntu/Debian:**
```bash
curl https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -
sudo apt-get install msodbcsql18 -y
```

### 3. Bağımlılıkları Yükle
```bash
pip install -r requirements.txt
```

> **Not:** `python-ldap` paketi Linux'ta `libldap-dev` gerektirir:
> ```bash
> sudo apt-get install libldap2-dev libsasl2-dev -y
> ```
> Windows'ta önceden derlenmiş wheel kullanın:
> ```bash
> pip install python-ldap --find-links https://www.lfd.uci.edu/~gohlke/pythonlibs/
> ```

### 4. Ortam Değişkenlerini Ayarla
```bash
cp .env.example .env
# .env dosyasını kendi değerlerinizle düzenleyin
```

### 5. Veritabanını Hazırla
```bash
python manage.py migrate
python manage.py createsuperuser  # İlk admin kullanıcısı
```

### 6. Sunucuyu Başlat
```bash
python manage.py runserver 0.0.0.0:8000
```

---

## API Endpoints

| Method | URL | Açıklama | Auth |
|--------|-----|----------|------|
| POST | `/api/auth/login/` | Giriş (LDAP/Local) | ❌ |
| POST | `/api/auth/logout/` | Çıkış | ✅ |
| GET  | `/api/auth/me/` | Kullanıcı bilgisi | ✅ |
| POST | `/api/auth/token/refresh/` | Token yenile | ❌ |
| GET  | `/api/auth/ldap-test/` | LDAP bağlantı testi | ✅ Admin |
| GET  | `/api/dashboard/stats/` | Dashboard istatistikleri | ✅ |
| POST | `/api/query/` | Ham SQL sorgusu | ✅ Admin |

---

## React Frontend Entegrasyonu

### Login isteği:
```javascript
const response = await fetch('http://localhost:8000/api/auth/login/', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username: 'ad_kullanici', password: 'sifre' })
});
const data = await response.json();
// data.tokens.access  → Authorization header'da kullan
// data.user           → Kullanıcı bilgisi
```

### Korunan endpoint'e istek:
```javascript
const response = await fetch('http://localhost:8000/api/dashboard/stats/', {
  headers: {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  }
});
```

---

## LDAP Yapılandırması (.env)

```
# Örnek Active Directory yapısı:
LDAP_SERVER_URI=ldap://ad.sirket.com.tr
LDAP_BIND_DN=CN=django_service,OU=ServiceAccounts,DC=sirket,DC=com,DC=tr
LDAP_BIND_PASSWORD=servis_hesabi_sifresi
LDAP_BASE_DN=DC=sirket,DC=com,DC=tr
LDAP_USER_SEARCH_OU=OU=Kullanicilar,DC=sirket,DC=com,DC=tr
LDAP_GROUP_SEARCH_OU=OU=Gruplar,DC=sirket,DC=com,DC=tr
```

---

## Proje Yapısı
```
dashboard_backend/
├── config/
│   ├── settings.py       ← Tüm konfigürasyon burада
│   ├── urls.py
│   └── wsgi.py
├── apps/
│   ├── authentication/   ← Login/Logout/LDAP
│   │   ├── views.py
│   │   ├── serializers.py
│   │   └── urls.py
│   └── api/              ← Dashboard endpoint'leri
│       ├── views.py
│       └── urls.py
├── manage.py
├── requirements.txt
└── .env.example
```
