// ─────────────────────────────────────────────
// useUrlMonitoring.js
// Auto-refreshing hook for the monitoring dashboard
// ─────────────────────────────────────────────
import { useState, useEffect, useCallback } from 'react';

const API_BASE = process.env.REACT_APP_API_URL ?? 'http://localhost:3000';
const REFRESH_MS = 30_000; // refresh every 30 s

export function useUrlMonitoring() {
  const [data,      setData]      = useState(null);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState(null);
  const [lastFetch, setLastFetch] = useState(null);

  const fetchDashboard = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/monitoring/dashboard`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
      setError(null);
      setLastFetch(new Date());
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
    const timer = setInterval(fetchDashboard, REFRESH_MS);
    return () => clearInterval(timer);
  }, [fetchDashboard]);

  // ── Mutations ──────────────────────────────────────────────────────────

  const addTarget = useCallback(async (dto) => {
    const res = await fetch(`${API_BASE}/monitoring/targets`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dto),
    });
    if (!res.ok) throw new Error(`Failed to create: HTTP ${res.status}`);
    await fetchDashboard();
  }, [fetchDashboard]);

  const deleteTarget = useCallback(async (id) => {
    const res = await fetch(`${API_BASE}/monitoring/targets/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error(`Failed to delete: HTTP ${res.status}`);
    await fetchDashboard();
  }, [fetchDashboard]);

  const triggerCheck = useCallback(async (id) => {
    const res = await fetch(`${API_BASE}/monitoring/targets/${id}/check`, {
      method: 'POST',
    });
    if (!res.ok) throw new Error(`Check failed: HTTP ${res.status}`);
    await fetchDashboard();
  }, [fetchDashboard]);

  return {
    data,
    loading,
    error,
    lastFetch,
    refresh: fetchDashboard,
    addTarget,
    deleteTarget,
    triggerCheck,
  };
}
