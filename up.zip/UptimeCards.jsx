// ─────────────────────────────────────────────
// UptimeCards.jsx – top-level summary cards
// ─────────────────────────────────────────────
export default function UptimeCards({ data }) {
  const cards = [
    {
      label: 'Monitored URLs',
      value: data.totalTargets,
      icon: '🔗',
      color: 'text-blue-600',
      bg: 'bg-blue-50 dark:bg-blue-900/20',
    },
    {
      label: 'Online',
      value: data.upCount,
      icon: '🟢',
      color: 'text-emerald-600',
      bg: 'bg-emerald-50 dark:bg-emerald-900/20',
    },
    {
      label: 'Down / Degraded',
      value: data.downCount + data.degradedCount,
      icon: '🔴',
      color: data.downCount > 0 ? 'text-red-600' : 'text-amber-500',
      bg: data.downCount > 0
        ? 'bg-red-50 dark:bg-red-900/20'
        : 'bg-amber-50 dark:bg-amber-900/20',
    },
    {
      label: 'Avg Uptime (30d)',
      value: `${data.avgUptimePercent}%`,
      icon: '📈',
      color: data.avgUptimePercent >= 99.9 ? 'text-emerald-600' : 'text-amber-500',
      bg: 'bg-gray-50 dark:bg-gray-800',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {cards.map((c, i) => (
        <div
          key={i}
          className={`${c.bg} rounded-xl p-4 flex items-center gap-4`}
        >
          <span className="text-2xl">{c.icon}</span>
          <div>
            <div className={`text-2xl font-bold ${c.color}`}>{c.value}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
              {c.label}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
