// ─────────────────────────────────────────────
// LatencySparkline.jsx
// Inline SVG chart – no extra dependency needed
// ─────────────────────────────────────────────

export default function LatencySparkline({ data = [], threshold = 2000, height = 48, width = 480 }) {
  if (data.length < 2) {
    return (
      <div
        className="flex items-center justify-center text-xs text-gray-400 bg-gray-100
                   dark:bg-gray-800 rounded"
        style={{ width, height }}
      >
        Not enough data
      </div>
    );
  }

  const values = data.map(d => d.responseTimeMs);
  const min    = Math.min(...values);
  const max    = Math.max(...values, threshold * 1.1);
  const range  = max - min || 1;

  const pad    = 4;
  const innerW = width - pad * 2;
  const innerH = height - pad * 2;

  const toX = (i) => pad + (i / (values.length - 1)) * innerW;
  const toY = (v) => pad + innerH - ((v - min) / range) * innerH;

  const linePath = values
    .map((v, i) => `${i === 0 ? 'M' : 'L'}${toX(i).toFixed(1)},${toY(v).toFixed(1)}`)
    .join(' ');

  const areaPath = [
    `M${toX(0).toFixed(1)},${(pad + innerH).toFixed(1)}`,
    ...values.map((v, i) => `L${toX(i).toFixed(1)},${toY(v).toFixed(1)}`),
    `L${toX(values.length - 1).toFixed(1)},${(pad + innerH).toFixed(1)}`,
    'Z',
  ].join(' ');

  // Threshold line Y
  const threshY = toY(threshold).toFixed(1);

  // Color last point
  const lastVal  = values.at(-1);
  const dotColor = lastVal > threshold ? '#f59e0b'
    : data.at(-1)?.status === 'DOWN' ? '#ef4444'
    : '#10b981';

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      width={width}
      height={height}
      className="overflow-visible"
    >
      <defs>
        <linearGradient id="spark-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="#6366f1" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Area fill */}
      <path d={areaPath} fill="url(#spark-fill)" />

      {/* Threshold dashed line */}
      {threshold < max && (
        <line
          x1={pad} y1={threshY} x2={pad + innerW} y2={threshY}
          stroke="#f59e0b" strokeWidth="1" strokeDasharray="4 3" opacity="0.7"
        />
      )}

      {/* Main line */}
      <path d={linePath} fill="none" stroke="#6366f1" strokeWidth="1.5" strokeLinejoin="round" />

      {/* Dots for DOWN events */}
      {data.map((d, i) => {
        if (d.status !== 'DOWN') return null;
        return (
          <circle
            key={i}
            cx={toX(i)} cy={toY(d.responseTimeMs)}
            r={3} fill="#ef4444"
          />
        );
      })}

      {/* Last value dot */}
      <circle
        cx={toX(values.length - 1)}
        cy={toY(lastVal)}
        r={4} fill={dotColor} stroke="#fff" strokeWidth="1.5"
      />
    </svg>
  );
}
