// ─────────────────────────────────────────────
// monitoring.service.ts
// ─────────────────────────────────────────────
import {
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import axios, { AxiosError } from 'axios';
import { v4 as uuid } from 'uuid';
import {
  UrlTarget,
  UrlCheckResult,
  IncidentRecord,
  UrlStats,
  DashboardPayload,
  UrlStatus,
  CreateUrlTargetDto,
  UpdateUrlTargetDto,
} from './monitoring.types';
import { AlertService } from '../alerts/alert.service';

// ─── In-memory store (swap with TypeORM entities in production) ──────────────
const targets   = new Map<string, UrlTarget>();
const results   = new Map<string, UrlCheckResult[]>();   // targetId → results[]
const incidents = new Map<string, IncidentRecord[]>();   // targetId → incidents[]
const openIncident = new Map<string, IncidentRecord>();  // targetId → open incident

@Injectable()
export class MonitoringService {
  private readonly logger = new Logger(MonitoringService.name);

  constructor(private readonly alertService: AlertService) {
    this._seedDefaults();
  }

  // ── CRUD ──────────────────────────────────────────────────────────────────

  async createTarget(dto: CreateUrlTargetDto): Promise<UrlTarget> {
    const target: UrlTarget = {
      id: uuid(),
      name: dto.name,
      url: dto.url,
      checkIntervalSeconds: dto.checkIntervalSeconds ?? 60,
      timeoutMs: dto.timeoutMs ?? 5000,
      expectedStatusCode: dto.expectedStatusCode ?? 200,
      alertThresholdMs: dto.alertThresholdMs ?? 2000,
      alertEmails: dto.alertEmails ?? [],
      tags: dto.tags ?? [],
      enabled: true,
      createdAt: new Date(),
    };
    targets.set(target.id, target);
    results.set(target.id, []);
    incidents.set(target.id, []);
    this.logger.log(`Target created: ${target.name} (${target.url})`);
    return target;
  }

  async updateTarget(id: string, dto: UpdateUrlTargetDto): Promise<UrlTarget> {
    const existing = this._getTargetOrThrow(id);
    const updated = { ...existing, ...dto };
    targets.set(id, updated);
    return updated;
  }

  async deleteTarget(id: string): Promise<void> {
    this._getTargetOrThrow(id);
    targets.delete(id);
    results.delete(id);
    incidents.delete(id);
    openIncident.delete(id);
  }

  listTargets(): UrlTarget[] {
    return [...targets.values()];
  }

  // ── CHECK ENGINE ──────────────────────────────────────────────────────────

  /** Called by the scheduler for a single target */
  async checkTarget(targetId: string): Promise<UrlCheckResult> {
    const target = this._getTargetOrThrow(targetId);
    const start  = Date.now();

    let httpStatusCode: number | null = null;
    let error: string | null = null;
    let status: UrlStatus = 'UP';

    try {
      const res = await axios.get(target.url, {
        timeout: target.timeoutMs,
        validateStatus: () => true,  // handle status manually
        maxRedirects: 5,
      });

      httpStatusCode = res.status;
      const responseTimeMs = Date.now() - start;

      if (res.status !== target.expectedStatusCode) {
        status = 'DOWN';
        error  = `Expected ${target.expectedStatusCode}, got ${res.status}`;
      } else if (responseTimeMs > target.alertThresholdMs) {
        status = 'DEGRADED';
      }

      const checkResult: UrlCheckResult = {
        id: uuid(),
        urlTargetId: targetId,
        checkedAt: new Date(),
        status,
        responseTimeMs,
        httpStatusCode,
        error,
      };

      this._saveResult(targetId, checkResult);
      await this._handleIncident(target, checkResult);
      return checkResult;

    } catch (err) {
      const axiosErr = err as AxiosError;
      error = axiosErr.message ?? 'Unknown error';
      status = 'DOWN';

      const checkResult: UrlCheckResult = {
        id: uuid(),
        urlTargetId: targetId,
        checkedAt: new Date(),
        status,
        responseTimeMs: Date.now() - start,
        httpStatusCode: null,
        error,
      };

      this._saveResult(targetId, checkResult);
      await this._handleIncident(target, checkResult);
      return checkResult;
    }
  }

  /** Run all enabled targets (called by scheduler) */
  async checkAll(): Promise<void> {
    const enabled = [...targets.values()].filter(t => t.enabled);
    this.logger.debug(`Running check on ${enabled.length} targets`);
    await Promise.allSettled(enabled.map(t => this.checkTarget(t.id)));
  }

  // ── STATS & DASHBOARD ─────────────────────────────────────────────────────

  getDashboard(): DashboardPayload {
    const statsArr = [...targets.values()].map(t => this._buildStats(t));

    const upCount       = statsArr.filter(s => s.latestStatus === 'UP').length;
    const downCount     = statsArr.filter(s => s.latestStatus === 'DOWN').length;
    const degradedCount = statsArr.filter(s => s.latestStatus === 'DEGRADED').length;
    const avgUptime     = statsArr.length
      ? statsArr.reduce((sum, s) => sum + s.uptimePercent, 0) / statsArr.length
      : 100;

    const recentIncidents = [...incidents.values()]
      .flat()
      .sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime())
      .slice(0, 20);

    return {
      generatedAt: new Date(),
      totalTargets: targets.size,
      upCount,
      downCount,
      degradedCount,
      avgUptimePercent: +avgUptime.toFixed(2),
      stats: statsArr,
      recentIncidents,
    };
  }

  getTargetStats(targetId: string): UrlStats {
    const target = this._getTargetOrThrow(targetId);
    return this._buildStats(target);
  }

  // ── PRIVATE HELPERS ───────────────────────────────────────────────────────

  private _buildStats(target: UrlTarget): UrlStats {
    const allResults = results.get(target.id) ?? [];
    const last50     = allResults.slice(-50);
    const last24h    = allResults.filter(
      r => r.checkedAt.getTime() > Date.now() - 86_400_000
    );
    const last30d    = allResults.filter(
      r => r.checkedAt.getTime() > Date.now() - 30 * 86_400_000
    );

    const latestCheck = last50.at(-1);
    const uptimeCount = last30d.filter(r => r.status !== 'DOWN').length;
    const uptimePct   = last30d.length ? (uptimeCount / last30d.length) * 100 : 100;

    const times24h    = last24h.map(r => r.responseTimeMs);
    const avg24h      = times24h.length
      ? times24h.reduce((a, b) => a + b, 0) / times24h.length
      : 0;
    const sorted      = [...times24h].sort((a, b) => a - b);
    const p95         = sorted[Math.floor(sorted.length * 0.95)] ?? 0;

    return {
      target,
      latestStatus:       latestCheck?.status ?? 'PENDING',
      latestResponseTimeMs: latestCheck?.responseTimeMs ?? 0,
      uptimePercent:      +uptimePct.toFixed(2),
      avgResponseTimeMs:  +avg24h.toFixed(0),
      p95ResponseTimeMs:  p95,
      checkCount:         allResults.length,
      incidentCount:      (incidents.get(target.id) ?? []).length,
      lastCheckedAt:      latestCheck?.checkedAt ?? null,
      history:            last50,
    };
  }

  private _saveResult(targetId: string, result: UrlCheckResult): void {
    const list = results.get(targetId) ?? [];
    list.push(result);
    // keep last 5000 per target
    if (list.length > 5000) list.splice(0, list.length - 5000);
    results.set(targetId, list);
  }

  private async _handleIncident(
    target: UrlTarget,
    result: UrlCheckResult
  ): Promise<void> {
    const open = openIncident.get(target.id);

    if (result.status === 'DOWN' || result.status === 'DEGRADED') {
      if (!open) {
        // Open new incident
        const incident: IncidentRecord = {
          id: uuid(),
          urlTargetId: target.id,
          urlName:     target.name,
          url:         target.url,
          startedAt:   new Date(),
          resolvedAt:  null,
          durationMs:  null,
          cause:       result.error ?? `Status: ${result.status}`,
        };
        openIncident.set(target.id, incident);
        const list = incidents.get(target.id) ?? [];
        list.push(incident);
        incidents.set(target.id, list);

        this.logger.warn(`🔴 Incident OPENED: ${target.name} – ${incident.cause}`);
        await this.alertService.sendDownAlert(target, incident, result);
      }
    } else {
      // UP – close open incident if any
      if (open) {
        open.resolvedAt = new Date();
        open.durationMs = open.resolvedAt.getTime() - open.startedAt.getTime();
        openIncident.delete(target.id);

        this.logger.log(`🟢 Incident RESOLVED: ${target.name} (${open.durationMs}ms down)`);
        await this.alertService.sendRecoveryAlert(target, open);
      }
    }
  }

  private _getTargetOrThrow(id: string): UrlTarget {
    const t = targets.get(id);
    if (!t) throw new NotFoundException(`URL target ${id} not found`);
    return t;
  }

  /** Seed a few example targets in dev */
  private _seedDefaults(): void {
    if (process.env.NODE_ENV === 'production') return;
    const seeds: CreateUrlTargetDto[] = [
      { name: 'Production API',     url: 'https://api.yourcompany.com/health', tags: ['api', 'prod'] },
      { name: 'Marketing Website',  url: 'https://www.yourcompany.com',        tags: ['web', 'prod'] },
      { name: 'CDN / Assets',       url: 'https://cdn.yourcompany.com',        tags: ['cdn'] },
    ];
    seeds.forEach(s => this.createTarget(s).catch(() => null));
  }
}
