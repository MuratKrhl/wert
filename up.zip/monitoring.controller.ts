// ─────────────────────────────────────────────
// monitoring.controller.ts
// ─────────────────────────────────────────────
import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { MonitoringService } from './monitoring.service';
import { CreateUrlTargetDto, UpdateUrlTargetDto } from './monitoring.types';

@Controller('monitoring')
export class MonitoringController {
  constructor(private readonly monitoringService: MonitoringService) {}

  // ── Dashboard ────────────────────────────────────────────────────────────

  /** GET /monitoring/dashboard  – full overview for the React UI */
  @Get('dashboard')
  getDashboard() {
    return this.monitoringService.getDashboard();
  }

  // ── Targets CRUD ─────────────────────────────────────────────────────────

  /** GET /monitoring/targets */
  @Get('targets')
  listTargets() {
    return this.monitoringService.listTargets();
  }

  /** POST /monitoring/targets */
  @Post('targets')
  createTarget(@Body() dto: CreateUrlTargetDto) {
    return this.monitoringService.createTarget(dto);
  }

  /** PUT /monitoring/targets/:id */
  @Put('targets/:id')
  updateTarget(@Param('id') id: string, @Body() dto: UpdateUrlTargetDto) {
    return this.monitoringService.updateTarget(id, dto);
  }

  /** DELETE /monitoring/targets/:id */
  @Delete('targets/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  deleteTarget(@Param('id') id: string) {
    return this.monitoringService.deleteTarget(id);
  }

  // ── Per-target stats ─────────────────────────────────────────────────────

  /** GET /monitoring/targets/:id/stats */
  @Get('targets/:id/stats')
  getTargetStats(@Param('id') id: string) {
    return this.monitoringService.getTargetStats(id);
  }

  /** POST /monitoring/targets/:id/check  – manual on-demand check */
  @Post('targets/:id/check')
  triggerCheck(@Param('id') id: string) {
    return this.monitoringService.checkTarget(id);
  }
}
