# URL Monitoring Module
## SolarWinds-style monitoring integrated into your existing React + NestJS dashboard

---

## 📦 Backend – NestJS Setup

### 1. Install dependencies
```bash
npm install @nestjs/schedule @nestjs/axios axios nodemailer uuid
npm install -D @types/nodemailer @types/uuid
```

### 2. Register the module in `app.module.ts`
```ts
import { MonitoringModule } from './modules/monitoring.module';

@Module({
  imports: [MonitoringModule],
})
export class AppModule {}
```

### 3. Environment variables (`.env`)
```env
# SMTP – for email alerts
SMTP_HOST=smtp.yourmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=alerts@yourcompany.com
SMTP_PASS=yourpassword
SMTP_FROM=alerts@yourcompany.com

# Webhook – optional (Slack, Teams, PagerDuty, etc.)
ALERT_WEBHOOK_URL=https://hooks.slack.com/services/XXX/YYY/ZZZ
```

### 4. REST Endpoints exposed

| Method | Path                            | Description               |
|--------|---------------------------------|---------------------------|
| GET    | `/monitoring/dashboard`         | Full overview payload     |
| GET    | `/monitoring/targets`           | List all URL targets      |
| POST   | `/monitoring/targets`           | Add a new URL target      |
| PUT    | `/monitoring/targets/:id`       | Update a target           |
| DELETE | `/monitoring/targets/:id`       | Remove a target           |
| GET    | `/monitoring/targets/:id/stats` | Per-target detailed stats |
| POST   | `/monitoring/targets/:id/check` | Trigger manual check      |

---

## 🎨 Frontend – React Setup

### 1. Set API base URL in `.env`
```env
REACT_APP_API_URL=http://localhost:3000
```

### 2. Drop into your existing Dashboard.jsx
```jsx
import UrlMonitoring from './components/url-monitor/UrlMonitoring';

export default function Dashboard() {
  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* ... your existing components ... */}

      {/* 👇 Add this */}
      <UrlMonitoring />
    </div>
  );
}
```

### 3. Component file structure
```
src/
├── components/
│   └── url-monitor/
│       ├── UrlMonitoring.jsx    ← main entry point
│       ├── UptimeCards.jsx      ← summary cards
│       ├── ServiceList.jsx      ← per-URL rows + sparkline
│       ├── LatencySparkline.jsx ← inline SVG chart
│       ├── IncidentLog.jsx      ← incident history
│       └── AddTargetModal.jsx   ← form + alert config
└── hooks/
    └── useUrlMonitoring.js      ← API + auto-refresh
```

---

## 🔥 Features

| Feature                    | Status |
|----------------------------|--------|
| HTTP health check (GET)    | ✅ |
| Custom expected status code | ✅ |
| Response time monitoring   | ✅ |
| Uptime % (30-day rolling)  | ✅ |
| P95 latency                | ✅ |
| Auto-refresh (30s)         | ✅ |
| Incident detection         | ✅ |
| Incident auto-resolution   | ✅ |
| Email alerts (nodemailer)  | ✅ |
| Webhook alerts             | ✅ |
| Latency sparkline chart    | ✅ |
| Manual on-demand check     | ✅ |
| Dark mode support          | ✅ |
| Persistent storage (TypeORM) | 🔲 swap in-memory → TypeORM entity |

---

## 🚀 Production Upgrade Path

1. **Persistence** – Replace in-memory Maps in `monitoring.service.ts` with TypeORM entities + PostgreSQL
2. **Per-target scheduling** – Add Redis-based queue (Bull) for granular per-target intervals
3. **Auth** – Protect endpoints with your existing RBAC guard
4. **Webhook presets** – Add Slack/Teams message formatters in `alert.service.ts`
5. **Multi-region checks** – Deploy the scheduler to multiple regions, aggregate results
