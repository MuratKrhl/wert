// ─────────────────────────────────────────────
// monitoring.types.ts  –  shared types
// ─────────────────────────────────────────────

export type UrlStatus = 'UP' | 'DOWN' | 'DEGRADED' | 'PENDING';

export interface UrlTarget {
  id: string;
  name: string;
  url: string;
  checkIntervalSeconds: number;  // default: 60
  timeoutMs: number;             // default: 5000
  expectedStatusCode: number;    // default: 200
  alertThresholdMs: number;      // latency above this → DEGRADED
  alertEmails: string[];
  tags: string[];
  enabled: boolean;
  createdAt: Date;
}

export interface UrlCheckResult {
  id: string;
  urlTargetId: string;
  checkedAt: Date;
  status: UrlStatus;
  responseTimeMs: number;
  httpStatusCode: number | null;
  error: string | null;
}

export interface IncidentRecord {
  id: string;
  urlTargetId: string;
  urlName: string;
  url: string;
  startedAt: Date;
  resolvedAt: Date | null;
  durationMs: number | null;
  cause: string;
}

export interface UrlStats {
  target: UrlTarget;
  latestStatus: UrlStatus;
  latestResponseTimeMs: number;
  uptimePercent: number;           // last 30 days
  avgResponseTimeMs: number;       // last 24 h
  p95ResponseTimeMs: number;       // last 24 h
  checkCount: number;
  incidentCount: number;
  lastCheckedAt: Date | null;
  history: UrlCheckResult[];       // last 50 checks (for spark-line)
}

export interface DashboardPayload {
  generatedAt: Date;
  totalTargets: number;
  upCount: number;
  downCount: number;
  degradedCount: number;
  avgUptimePercent: number;
  stats: UrlStats[];
  recentIncidents: IncidentRecord[];
}

// ─── DTOs ────────────────────────────────────

export interface CreateUrlTargetDto {
  name: string;
  url: string;
  checkIntervalSeconds?: number;
  timeoutMs?: number;
  expectedStatusCode?: number;
  alertThresholdMs?: number;
  alertEmails?: string[];
  tags?: string[];
}

export interface UpdateUrlTargetDto extends Partial<CreateUrlTargetDto> {
  enabled?: boolean;
}
