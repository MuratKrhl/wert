// ─────────────────────────────────────────────
// IncidentLog.jsx – historical incident list
// ─────────────────────────────────────────────

export default function IncidentLog({ incidents = [] }) {
  if (!incidents.length) {
    return (
      <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-8 text-center">
        <p className="text-2xl mb-2">🎉</p>
        <p className="text-emerald-700 dark:text-emerald-400 font-medium">
          No incidents recorded
        </p>
        <p className="text-sm text-emerald-600 dark:text-emerald-500 mt-1">
          All monitored URLs are running smoothly.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200
                    dark:border-gray-700 overflow-hidden">
      <div className="grid grid-cols-12 gap-4 px-5 py-3 text-xs font-semibold
                      uppercase tracking-wide text-gray-400 border-b
                      border-gray-100 dark:border-gray-700">
        <div className="col-span-1">State</div>
        <div className="col-span-3">Service</div>
        <div className="col-span-3">Started</div>
        <div className="col-span-3">Resolved</div>
        <div className="col-span-2">Duration</div>
      </div>

      {incidents.map((inc, i) => {
        const isOpen = !inc.resolvedAt;
        const duration = inc.durationMs ? formatDuration(inc.durationMs) : '—';

        return (
          <div
            key={inc.id ?? i}
            className="grid grid-cols-12 gap-4 px-5 py-4 items-start
                       border-b border-gray-50 dark:border-gray-800
                       hover:bg-gray-50 dark:hover:bg-gray-800/40 transition"
          >
            {/* State */}
            <div className="col-span-1 pt-0.5">
              {isOpen ? (
                <span className="inline-flex items-center gap-1 text-xs font-semibold
                                 text-red-700 bg-red-100 px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                  Live
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-semibold
                                 text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                  ✓ Done
                </span>
              )}
            </div>

            {/* Service info */}
            <div className="col-span-3 min-w-0">
              <div className="text-sm font-medium text-gray-900 dark:text-white truncate">
                {inc.urlName}
              </div>
              <div className="text-xs text-gray-400 truncate mt-0.5">{inc.url}</div>
              {inc.cause && (
                <div className="text-xs text-red-500 mt-1 truncate">
                  {inc.cause}
                </div>
              )}
            </div>

            {/* Started */}
            <div className="col-span-3 text-sm text-gray-600 dark:text-gray-300">
              {formatDate(inc.startedAt)}
            </div>

            {/* Resolved */}
            <div className="col-span-3 text-sm text-gray-600 dark:text-gray-300">
              {inc.resolvedAt ? formatDate(inc.resolvedAt) : (
                <span className="text-red-500 font-medium">Ongoing</span>
              )}
            </div>

            {/* Duration */}
            <div className={`col-span-2 text-sm font-mono font-semibold
              ${inc.durationMs && inc.durationMs > 300_000
                ? 'text-red-500'
                : 'text-gray-700 dark:text-gray-200'
              }`}>
              {duration}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function formatDate(raw) {
  const d = typeof raw === 'string' ? new Date(raw) : raw;
  return d.toLocaleString(undefined, {
    month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

function formatDuration(ms) {
  if (ms < 60_000)    return `${Math.round(ms / 1000)}s`;
  if (ms < 3_600_000) return `${Math.round(ms / 60_000)}m`;
  return `${(ms / 3_600_000).toFixed(1)}h`;
}
