// ─────────────────────────────────────────────
// ServiceList.jsx – per-URL status rows
// ─────────────────────────────────────────────
import { useState } from 'react';
import LatencySparkline from './LatencySparkline';

const STATUS_CONFIG = {
  UP:       { dot: 'bg-emerald-400', badge: 'text-emerald-700 bg-emerald-100', label: 'UP' },
  DOWN:     { dot: 'bg-red-500 animate-pulse', badge: 'text-red-700 bg-red-100', label: 'DOWN' },
  DEGRADED: { dot: 'bg-amber-400', badge: 'text-amber-700 bg-amber-100', label: 'DEGRADED' },
  PENDING:  { dot: 'bg-gray-300', badge: 'text-gray-600 bg-gray-100', label: 'PENDING' },
};

export default function ServiceList({ stats, onDelete, onCheck }) {
  const [checkingId, setCheckingId] = useState(null);
  const [expanded,   setExpanded]   = useState(null);

  const handleCheck = async (id) => {
    setCheckingId(id);
    try { await onCheck(id); } finally { setCheckingId(null); }
  };

  if (!stats.length) {
    return (
      <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-10 text-center">
        <p className="text-gray-400 text-sm">No URLs configured yet. Click "Add URL" to get started.</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200
                    dark:border-gray-700 overflow-hidden">
      {/* Table header */}
      <div className="grid grid-cols-12 gap-4 px-5 py-3 text-xs font-semibold
                      uppercase tracking-wide text-gray-400 border-b
                      border-gray-100 dark:border-gray-700">
        <div className="col-span-4">Service / URL</div>
        <div className="col-span-1 text-center">Status</div>
        <div className="col-span-2 text-right">Response (ms)</div>
        <div className="col-span-2 text-right">Avg 24h (ms)</div>
        <div className="col-span-1 text-right">Uptime</div>
        <div className="col-span-2 text-right">Actions</div>
      </div>

      {/* Rows */}
      {stats.map((s) => {
        const cfg  = STATUS_CONFIG[s.latestStatus] ?? STATUS_CONFIG.PENDING;
        const isEx = expanded === s.target.id;

        return (
          <div key={s.target.id}>
            {/* Main row */}
            <div
              className="grid grid-cols-12 gap-4 px-5 py-4 items-center
                         hover:bg-gray-50 dark:hover:bg-gray-800/50 transition
                         border-b border-gray-50 dark:border-gray-800 cursor-pointer"
              onClick={() => setExpanded(isEx ? null : s.target.id)}
            >
              {/* Name + URL */}
              <div className="col-span-4 flex items-center gap-3 min-w-0">
                <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${cfg.dot}`} />
                <div className="min-w-0">
                  <div className="font-medium text-sm text-gray-900 dark:text-white truncate">
                    {s.target.name}
                  </div>
                  <div className="text-xs text-gray-400 truncate">{s.target.url}</div>
                </div>
              </div>

              {/* Status badge */}
              <div className="col-span-1 flex justify-center">
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${cfg.badge}`}>
                  {cfg.label}
                </span>
              </div>

              {/* Latest response time */}
              <div className="col-span-2 text-right">
                <span className={`text-sm font-mono font-semibold ${
                  s.latestResponseTimeMs > s.target.alertThresholdMs
                    ? 'text-amber-500'
                    : 'text-gray-700 dark:text-gray-200'
                }`}>
                  {s.latestResponseTimeMs > 0 ? s.latestResponseTimeMs : '—'}
                </span>
              </div>

              {/* Avg 24h */}
              <div className="col-span-2 text-right text-sm font-mono text-gray-500">
                {s.avgResponseTimeMs > 0 ? s.avgResponseTimeMs : '—'}
              </div>

              {/* Uptime */}
              <div className="col-span-1 text-right">
                <UptimeBadge value={s.uptimePercent} />
              </div>

              {/* Actions */}
              <div className="col-span-2 flex justify-end gap-2"
                   onClick={e => e.stopPropagation()}>
                <button
                  title="Run check now"
                  disabled={checkingId === s.target.id}
                  onClick={() => handleCheck(s.target.id)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-indigo-600
                             hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition disabled:opacity-40"
                >
                  {checkingId === s.target.id ? '⏳' : '▶'}
                </button>
                <button
                  title="Delete"
                  onClick={() => onDelete(s.target.id)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-red-500
                             hover:bg-red-50 dark:hover:bg-red-900/30 transition"
                >
                  🗑
                </button>
              </div>
            </div>

            {/* Expanded sparkline row */}
            {isEx && (
              <div className="px-5 py-4 bg-gray-50 dark:bg-gray-800/30 border-b
                              border-gray-100 dark:border-gray-700">
                <div className="flex gap-8 items-start">
                  <div className="flex-1">
                    <p className="text-xs text-gray-400 mb-2">
                      Response time – last {s.history.length} checks
                    </p>
                    <LatencySparkline data={s.history} threshold={s.target.alertThresholdMs} />
                  </div>
                  <div className="flex gap-6 text-center text-sm">
                    <Stat label="P95" value={`${s.p95ResponseTimeMs}ms`} />
                    <Stat label="Incidents" value={s.incidentCount} />
                    <Stat label="Checks" value={s.checkCount} />
                    <Stat label="Interval" value={`${s.target.checkIntervalSeconds}s`} />
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function UptimeBadge({ value }) {
  const color = value >= 99.9
    ? 'text-emerald-600'
    : value >= 99
      ? 'text-amber-500'
      : 'text-red-500';
  return <span className={`text-sm font-semibold ${color}`}>{value}%</span>;
}

function Stat({ label, value }) {
  return (
    <div>
      <div className="text-sm font-semibold text-gray-700 dark:text-gray-200">{value}</div>
      <div className="text-xs text-gray-400 mt-0.5">{label}</div>
    </div>
  );
}
