// ─────────────────────────────────────────────
// alert.service.ts
// Sends email + webhook alerts on DOWN / RECOVERY
// ─────────────────────────────────────────────
import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import axios from 'axios';
import {
  UrlTarget,
  UrlCheckResult,
  IncidentRecord,
} from '../monitoring/monitoring.types';

@Injectable()
export class AlertService {
  private readonly logger = new Logger(AlertService.name);

  // ── nodemailer transporter (configure via env) ───────────────────────────
  private transporter = nodemailer.createTransport({
    host:   process.env.SMTP_HOST   ?? 'smtp.yourmail.com',
    port:   Number(process.env.SMTP_PORT ?? 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER ?? '',
      pass: process.env.SMTP_PASS ?? '',
    },
  });

  // ── Public API ────────────────────────────────────────────────────────────

  async sendDownAlert(
    target: UrlTarget,
    incident: IncidentRecord,
    result: UrlCheckResult
  ): Promise<void> {
    const subject = `🔴 [DOWN] ${target.name} is unavailable`;
    const html    = this._buildDownEmail(target, incident, result);

    await this._sendEmails(target.alertEmails, subject, html);
    await this._sendWebhook({
      event:     'DOWN',
      targetId:  target.id,
      targetName: target.name,
      url:       target.url,
      incidentId: incident.id,
      startedAt: incident.startedAt,
      cause:     incident.cause,
      httpStatus: result.httpStatusCode,
      responseMs: result.responseTimeMs,
    });
  }

  async sendRecoveryAlert(
    target: UrlTarget,
    incident: IncidentRecord
  ): Promise<void> {
    const durationStr = incident.durationMs
      ? this._formatDuration(incident.durationMs)
      : 'unknown';

    const subject = `🟢 [RECOVERED] ${target.name} is back online`;
    const html    = this._buildRecoveryEmail(target, incident, durationStr);

    await this._sendEmails(target.alertEmails, subject, html);
    await this._sendWebhook({
      event:      'RECOVERED',
      targetId:   target.id,
      targetName: target.name,
      url:        target.url,
      incidentId: incident.id,
      startedAt:  incident.startedAt,
      resolvedAt: incident.resolvedAt,
      durationMs: incident.durationMs,
    });
  }

  // ── Private helpers ───────────────────────────────────────────────────────

  private async _sendEmails(
    recipients: string[],
    subject: string,
    html: string
  ): Promise<void> {
    if (!recipients.length) return;

    try {
      await this.transporter.sendMail({
        from:    process.env.SMTP_FROM ?? 'alerts@yourcompany.com',
        to:      recipients.join(', '),
        subject,
        html,
      });
      this.logger.log(`Alert email sent to: ${recipients.join(', ')}`);
    } catch (err) {
      this.logger.error('Failed to send alert email', err);
    }
  }

  private async _sendWebhook(payload: Record<string, unknown>): Promise<void> {
    const webhookUrl = process.env.ALERT_WEBHOOK_URL;
    if (!webhookUrl) return;

    try {
      await axios.post(webhookUrl, payload, { timeout: 5000 });
      this.logger.log(`Webhook sent to: ${webhookUrl}`);
    } catch (err) {
      this.logger.warn('Webhook delivery failed', err);
    }
  }

  private _buildDownEmail(
    target: UrlTarget,
    incident: IncidentRecord,
    result: UrlCheckResult
  ): string {
    return `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <div style="background:#ef4444;color:#fff;padding:20px;border-radius:8px 8px 0 0">
          <h2 style="margin:0">🔴 Service Down</h2>
        </div>
        <div style="background:#fff;padding:24px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 8px 8px">
          <p><strong>${target.name}</strong> is currently <strong>DOWN</strong>.</p>
          <table style="width:100%;border-collapse:collapse;font-size:14px">
            <tr><td style="padding:8px;color:#6b7280">URL</td><td>${target.url}</td></tr>
            <tr><td style="padding:8px;color:#6b7280">Time</td><td>${incident.startedAt.toISOString()}</td></tr>
            <tr><td style="padding:8px;color:#6b7280">HTTP Status</td><td>${result.httpStatusCode ?? 'No response'}</td></tr>
            <tr><td style="padding:8px;color:#6b7280">Response Time</td><td>${result.responseTimeMs}ms</td></tr>
            <tr><td style="padding:8px;color:#6b7280">Error</td><td>${result.error ?? '—'}</td></tr>
          </table>
        </div>
      </div>`;
  }

  private _buildRecoveryEmail(
    target: UrlTarget,
    incident: IncidentRecord,
    duration: string
  ): string {
    return `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
        <div style="background:#22c55e;color:#fff;padding:20px;border-radius:8px 8px 0 0">
          <h2 style="margin:0">🟢 Service Recovered</h2>
        </div>
        <div style="background:#fff;padding:24px;border:1px solid #e5e7eb;border-top:0;border-radius:0 0 8px 8px">
          <p><strong>${target.name}</strong> is back online after being down for <strong>${duration}</strong>.</p>
          <table style="width:100%;border-collapse:collapse;font-size:14px">
            <tr><td style="padding:8px;color:#6b7280">URL</td><td>${target.url}</td></tr>
            <tr><td style="padding:8px;color:#6b7280">Down since</td><td>${incident.startedAt.toISOString()}</td></tr>
            <tr><td style="padding:8px;color:#6b7280">Recovered at</td><td>${incident.resolvedAt?.toISOString()}</td></tr>
            <tr><td style="padding:8px;color:#6b7280">Total downtime</td><td>${duration}</td></tr>
          </table>
        </div>
      </div>`;
  }

  private _formatDuration(ms: number): string {
    if (ms < 60_000)     return `${Math.round(ms / 1000)}s`;
    if (ms < 3_600_000)  return `${Math.round(ms / 60_000)}m`;
    return `${(ms / 3_600_000).toFixed(1)}h`;
  }
}
