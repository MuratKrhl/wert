// ─────────────────────────────────────────────
// UrlMonitoring.jsx
// Drop into your existing Dashboard.jsx like:
//   import UrlMonitoring from './url-monitor/UrlMonitoring';
//   <UrlMonitoring />
// ─────────────────────────────────────────────
import { useState } from 'react';
import { useUrlMonitoring } from '../../hooks/useUrlMonitoring';
import UptimeCards    from './UptimeCards';
import ServiceList    from './ServiceList';
import LatencySparkline from './LatencySparkline';
import IncidentLog    from './IncidentLog';
import AddTargetModal from './AddTargetModal';

export default function UrlMonitoring() {
  const {
    data, loading, error, lastFetch,
    refresh, addTarget, deleteTarget, triggerCheck,
  } = useUrlMonitoring();

  const [showModal, setShowModal] = useState(false);
  const [activeTab, setActiveTab] = useState('overview'); // overview | incidents

  if (loading) return <LoadingState />;
  if (error)   return <ErrorState message={error} onRetry={refresh} />;
  if (!data)   return null;

  return (
    <section className="space-y-5">

      {/* ── Section Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            URL Monitoring
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            Auto-refreshes every 30s
            {lastFetch && (
              <> · Last updated {lastFetch.toLocaleTimeString()}</>
            )}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={refresh}
            className="p-2 rounded-lg text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition"
            title="Refresh now"
          >
            <RefreshIcon />
          </button>

          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700
                       text-white text-sm font-medium rounded-lg transition"
          >
            <PlusIcon /> Add URL
          </button>
        </div>
      </div>

      {/* ── Summary Cards ── */}
      <UptimeCards data={data} />

      {/* ── Tab Bar ── */}
      <div className="flex gap-1 border-b border-gray-200 dark:border-gray-700">
        {['overview', 'incidents'].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium capitalize transition-colors
              ${activeTab === tab
                ? 'border-b-2 border-indigo-600 text-indigo-600'
                : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
          >
            {tab}
            {tab === 'incidents' && data.recentIncidents.length > 0 && (
              <span className="ml-2 bg-red-100 text-red-700 text-xs px-1.5 py-0.5 rounded-full">
                {data.recentIncidents.filter(i => !i.resolvedAt).length || ''}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* ── Tab Panels ── */}
      {activeTab === 'overview' && (
        <ServiceList
          stats={data.stats}
          onDelete={deleteTarget}
          onCheck={triggerCheck}
        />
      )}

      {activeTab === 'incidents' && (
        <IncidentLog incidents={data.recentIncidents} />
      )}

      {/* ── Add Target Modal ── */}
      {showModal && (
        <AddTargetModal
          onClose={() => setShowModal(false)}
          onSave={async (dto) => {
            await addTarget(dto);
            setShowModal(false);
          }}
        />
      )}
    </section>
  );
}

// ── Sub-components ──────────────────────────────────────────────────────────

function LoadingState() {
  return (
    <div className="space-y-3">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="h-20 bg-gray-100 dark:bg-gray-800 rounded-xl animate-pulse" />
      ))}
    </div>
  );
}

function ErrorState({ message, onRetry }) {
  return (
    <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800
                    rounded-xl p-5 flex items-start gap-4">
      <span className="text-red-500 text-xl">⚠</span>
      <div>
        <p className="font-medium text-red-700 dark:text-red-400">
          Failed to load monitoring data
        </p>
        <p className="text-sm text-red-600 dark:text-red-500 mt-1">{message}</p>
        <button
          onClick={onRetry}
          className="mt-3 text-sm text-red-700 underline hover:no-underline"
        >
          Try again
        </button>
      </div>
    </div>
  );
}

// ── Icons ───────────────────────────────────────────────────────────────────

function RefreshIcon() {
  return (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
        d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
  );
}
