// ─────────────────────────────────────────────
// monitoring.module.ts
// ─────────────────────────────────────────────
import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { ScheduleModule } from '@nestjs/schedule';
import { MonitoringService }    from './monitoring/monitoring.service';
import { MonitoringController } from './monitoring/monitoring.controller';
import { MonitoringScheduler }  from './monitoring/monitoring.scheduler';
import { AlertService }         from './alerts/alert.service';

@Module({
  imports: [
    HttpModule,
    ScheduleModule.forRoot(),
  ],
  providers: [
    MonitoringService,
    MonitoringScheduler,
    AlertService,
  ],
  controllers: [MonitoringController],
  exports: [MonitoringService],
})
export class MonitoringModule {}

// ─────────────────────────────────────────────
// app.module.ts  (add MonitoringModule here)
// ─────────────────────────────────────────────
/*
import { Module }         from '@nestjs/common';
import { MonitoringModule } from './modules/monitoring.module';

@Module({
  imports: [MonitoringModule],
})
export class AppModule {}
*/
