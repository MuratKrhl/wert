// ─────────────────────────────────────────────
// monitoring.scheduler.ts
// Runs periodic health checks via @nestjs/schedule
// ─────────────────────────────────────────────
import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { MonitoringService } from './monitoring.service';

@Injectable()
export class MonitoringScheduler {
  private readonly logger = new Logger(MonitoringScheduler.name);

  constructor(private readonly monitoringService: MonitoringService) {}

  /**
   * Default: every minute.
   * Per-target interval granularity can be layered on top by
   * comparing target.checkIntervalSeconds against time-since-last-check.
   */
  @Cron(CronExpression.EVERY_MINUTE)
  async runChecks() {
    this.logger.debug('⏱  Scheduled check cycle starting...');
    await this.monitoringService.checkAll();
  }
}
