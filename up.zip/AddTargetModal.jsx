// ─────────────────────────────────────────────
// AddTargetModal.jsx
// Form to add a new URL target + alert settings
// ─────────────────────────────────────────────
import { useState } from 'react';

const DEFAULTS = {
  name:                 '',
  url:                  'https://',
  checkIntervalSeconds: 60,
  timeoutMs:            5000,
  expectedStatusCode:   200,
  alertThresholdMs:     2000,
  alertEmails:          '',
  tags:                 '',
};

export default function AddTargetModal({ onClose, onSave }) {
  const [form,    setForm]    = useState(DEFAULTS);
  const [saving,  setSaving]  = useState(false);
  const [errors,  setErrors]  = useState({});

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const validate = () => {
    const e = {};
    if (!form.name.trim())          e.name = 'Name is required';
    if (!/^https?:\/\/.+/.test(form.url)) e.url  = 'Enter a valid URL';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      await onSave({
        name:                 form.name.trim(),
        url:                  form.url.trim(),
        checkIntervalSeconds: Number(form.checkIntervalSeconds),
        timeoutMs:            Number(form.timeoutMs),
        expectedStatusCode:   Number(form.expectedStatusCode),
        alertThresholdMs:     Number(form.alertThresholdMs),
        alertEmails:          form.alertEmails
          .split(',').map(s => s.trim()).filter(Boolean),
        tags: form.tags
          .split(',').map(s => s.trim()).filter(Boolean),
      });
    } catch (err) {
      alert(`Failed: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    /* Backdrop */
    <div
      className="fixed inset-0 z-50 flex items-center justify-center
                 bg-black/40 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      {/* Panel */}
      <div
        className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-lg
                   border border-gray-200 dark:border-gray-700"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b
                        border-gray-100 dark:border-gray-700">
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">
            Add URL Target
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto">

          <Field label="Name *" error={errors.name}>
            <input
              type="text"
              value={form.name}
              onChange={e => set('name', e.target.value)}
              placeholder="Production API"
              className={inputCls(errors.name)}
            />
          </Field>

          <Field label="URL *" error={errors.url}>
            <input
              type="url"
              value={form.url}
              onChange={e => set('url', e.target.value)}
              placeholder="https://api.yourcompany.com/health"
              className={inputCls(errors.url)}
            />
          </Field>

          <div className="grid grid-cols-2 gap-4">
            <Field label="Check Interval (s)">
              <input
                type="number" min="10" max="3600"
                value={form.checkIntervalSeconds}
                onChange={e => set('checkIntervalSeconds', e.target.value)}
                className={inputCls()}
              />
            </Field>

            <Field label="Expected HTTP Status">
              <input
                type="number" min="100" max="599"
                value={form.expectedStatusCode}
                onChange={e => set('expectedStatusCode', e.target.value)}
                className={inputCls()}
              />
            </Field>

            <Field label="Timeout (ms)">
              <input
                type="number" min="500" max="30000"
                value={form.timeoutMs}
                onChange={e => set('timeoutMs', e.target.value)}
                className={inputCls()}
              />
            </Field>

            <Field label="Alert if latency > (ms)">
              <input
                type="number" min="100"
                value={form.alertThresholdMs}
                onChange={e => set('alertThresholdMs', e.target.value)}
                className={inputCls()}
              />
            </Field>
          </div>

          <Field label="Alert Emails (comma-separated)">
            <input
              type="text"
              value={form.alertEmails}
              onChange={e => set('alertEmails', e.target.value)}
              placeholder="ops@company.com, oncall@company.com"
              className={inputCls()}
            />
          </Field>

          <Field label="Tags (comma-separated)">
            <input
              type="text"
              value={form.tags}
              onChange={e => set('tags', e.target.value)}
              placeholder="api, prod, critical"
              className={inputCls()}
            />
          </Field>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 px-6 py-4 border-t
                        border-gray-100 dark:border-gray-700">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm text-gray-600 dark:text-gray-300
                       hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="px-5 py-2 text-sm font-medium bg-indigo-600 hover:bg-indigo-700
                       text-white rounded-lg transition disabled:opacity-60"
          >
            {saving ? 'Saving…' : 'Add URL'}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children, error }) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5">
        {label}
      </label>
      {children}
      {error && (
        <p className="text-xs text-red-500 mt-1">{error}</p>
      )}
    </div>
  );
}

const inputCls = (error) =>
  `w-full px-3 py-2 text-sm rounded-lg border
   bg-white dark:bg-gray-800 text-gray-900 dark:text-white
   focus:outline-none focus:ring-2 focus:ring-indigo-500 transition
   ${error
     ? 'border-red-400'
     : 'border-gray-200 dark:border-gray-600'
   }`;
